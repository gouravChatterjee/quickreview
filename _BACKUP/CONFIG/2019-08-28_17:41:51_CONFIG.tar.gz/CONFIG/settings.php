<?php

define("DOMAIN_NAME", "franchisee.beanstalkedu.com");



?>
