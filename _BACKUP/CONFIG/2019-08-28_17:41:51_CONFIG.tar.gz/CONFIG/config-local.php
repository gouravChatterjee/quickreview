<?php
//include "../DIZ/DirectAccess-preventer.php";
define("APP_NAME", "BSfranchiseePortal");

define("HTTP_HOST", "");//$_SERVER['HTTP_HOST'] == 'localhost:8080';$_SERVER['SERVER_NAME'] == 'localhost';

define("F_D",0);


define("MYSQL_HOST", "localhost");
define("MYSQL_USER", "admin_frp");
define("MYSQL_PASS", "000000");
define("MYSQL_DB_BEANSTALKFP", "admin_frp");
define("FRP_TB_BOOK_COST", "FRP_TB_BOOK_COST");
define("FRP_TB_ANNEXURE_PROGRAM", "FRP_TB_ANNEXURE_PROGRAM");
define("FRP_TB_FRANCHISE_LIST", "FRP_TB_FRANCHISE_LIST");
define("FRP_TB_EXAM_CONTROL", "FRP_TB_EXAM_CONTROL");
define("FRP_TB_NON_STUDENT_REGISTER", "FRP_TB_NON_STUDENT_REGISTER");
define("FRP_TB_STUDENT_REGISTER", "FRP_TB_STUDENT_REGISTER");
define("BS_USER", "BS_USER");
define("BS_INVENTORY", "BS_INVENTORY");

// $host="localhost";
// $user= "test_colleger";
// $pass = "simple2pass";
// $db = "test_colleger";
// $table1= "amdanga_pages";
// $table2= "admission";
// $table4= "scc_pg_18";
// $user_google = "user_google";
$GLOBALS['table_user']="user1";
?>
