<?php
	// Installed the need packages with Composer by running:
	// $ composer require aws/aws-sdk-php

	$fruits = array("d" => "lemon", "a" => "orange", "b" => "banana", "c" => "apple");

	function test_alter(&$item1, $key, $prefix)
	{
	    $item1 = "$prefix: $item1";
	}

	function test_print($item2, $key)
	{
	    echo "$key. $item2<br />\n";
	}

	echo "Before ...:\n";
	array_walk($fruits, 'test_print');

	array_walk($fruits, 'test_alter', 'fruit');
	echo "... and after:\n";

	array_walk($fruits, 'test_print');


	$filePath = "https://example.com/test.png";
	require 'SDK/DO_Spaces/spaces.php';
	$bucketName = 'rolebased';
	$filePath = './0.png';
	$keyName = basename($filePath);

	$key = "HV7PQIVTDNXOFMPPK3YV";
	$secret = "28L78eXcZT5qwJkbkX/+ed61pw9yOdS4Cgn3wY4WmMc";

	$space_name = "rolebased";
	$region = "sgp1";

	$space = new SpacesConnect($key, $secret, $space_name, $region);

	try {
	   // $space->CreateSpace("dev");
		 $files = $space->ListObjects();
		 foreach($files as $value){
			 $Fname=end(explode('/', $value['Key']));
			 if($Fname=='')echo $value['Key'];
			 else echo $Fname;

			  // echo $value['Key']," <br>";
			}
		 // echo $files[0]['Key'];
		 // echo "<pre>";
	   // print_r($files);
		 // echo "</pre>";
	} catch (\SpacesAPIException $e) {
	  $error = $e->GetError();

	   //Error management code.
	   echo "<pre>";
	   print_r($error);
		 echo "</pre>";
	   /*
	   EG:
	   Array (
	    [message] => Bucket already exists
	    [code] => BucketAlreadyExists
	    [type] => client
	    [http_code] => 409
	   )
	   */
	}
?>
