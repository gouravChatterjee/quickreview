
<script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
</script>


<?php

$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);

if(mysqli_connect_error()){
	die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}

if (isset($_POST['submit'])){


	if(isset($_POST['frname']))
		$frname = $_POST['frname'];
	if(isset($_POST['country']))
		$country = $_POST['country'];
	if(isset($_POST['state']))
		$state = $_POST['state'];
	if(isset($_POST['city']))
		$city = $_POST['city'];
	if(isset($_POST['program']))
		$program = $_POST['program'];
	if(isset($_POST['vfrom']))
		$vfrom = $_POST['vfrom'];
	if(isset($_POST['vto']))
		$vto = $_POST['vto'];
	if(isset($_POST['phn']))
		$phn = $_POST['phn'];
	if(isset($_POST['email']))
		$email = $_POST['email'];
	if(isset($_POST['line1']))
		$line1 = $_POST['line1'];
	if(isset($_POST['pin']))
		$pin = $_POST['pin'];
	$program = implode(",", $program);



	$image = $_FILES['image']['name'];

	$details['Details'] = array("Programs" => $program);
	$details['ValidFr'] = array("ValidFrom"=>$vfrom);
	$details['ValidTo'] = array("ValidTo"=>$vto);

	$details['Address'] = array("FranName"=>$frname, "Line1"=>$line1, "City"=>$city, "Pin"=>$pin, "Country"=>$country, "State"=>$state, "Agreement"=>$image);

	
 
	$details =  json_encode($details);

	// $sql = "SELECT BS_USER_AUTOID FROM BS_USER";

	// $result = mysqli_query($link, $sql);
	// if($result){
	// 	if(mysqli_num_rows($result)>0){
	// 				while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
	// 					echo "   ".$row['BS_USER_AUTOID'];
	// 				}


	// 			}
	// }
	 $sql = "SELECT * FROM BS_USER WHERE `USER_EMAIL` = '$email'";
          $result = mysqli_query($link, $sql);

          $results = mysqli_num_rows($result);
          if($results){
          	 $GLOBALS['alert_info'] .= DaddToBsAlert("That email is already registered. Please Check again!!");
          }else{
          	$sql = "INSERT INTO BS_USER (`USER_JSOND`, `BS_USER_TYPE`, `USER_FULL_NAME`, `USER_PHONE`, `USER_EMAIL`)VALUES('$details', 'FRANSCHISE', '$frname', '$phn','$email')";

			$result = mysqli_query($link, $sql);

			$id = mysqli_insert_id($link);

			$fileName = "AgreementCopy";
			
			
			// echo '<div class="alert alert-danger">'.$Id.'</div>';
			mkdir("CONTENT/UPLOADS/FRANCHISE/".$id."/Agreement", 0755, true);
			

			$target = "CONTENT/UPLOADS/FRANCHISE/".$id."/Agreement/".basename($image);
			// echo "  ".$target;


			if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
		  		$msg = "Image uploaded successfully";
		  		// echo $msg;
		  	}else{
		  		$msg = "Failed to upload image";
		  		// echo "not uploaded";
		  	}

		  	if(!$result){
				echo '<div class="alert alert-danger">There was a database error </div>';
				echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
				exit;
			}else{


				echo '<div class="alert alert-success">successfully Registered Franchise</div>';



			}

          }




	// $itemid = mysqli_real_escape_string($link,$itemid);
	// $itemdesc = mysqli_real_escape_string($link,$itemdesc);
	// $cost = mysqli_real_escape_string($link,$cost);

	// $sql = "INSERT INTO FRP_TB_FRANCHISE_LIST (`FRAN_NAME`, `COUNTRY`, `STATE`, `CITY`, `PROGRAM`, `VALID_FROM`,`VALID_TO`,`AGREEMENT_COPY`,`PHN_NO`,`EMAIL`)VALUES('$frname', '$country', '$state', '$city', '$program', '$vfrom','$vto','$image','$phn','$email')";
	
}

if ($GLOBALS['alert_info']!="") {
  echo $GLOBALS['alert_info'];
}





?>









<div class="container">

<div class="col-sm-10 ml-auto mr-auto">
	<div class="tab-content" id="pills-tabContent">
		<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
            <div class="col-sm-12 border border-primary shadow rounded pt-2">


		<h2 style="text-align: center;">FRANCHISEE CREATION</h1>
			<hr>

		<form action="registerFranchise" method="POST" enctype="multipart/form-data">

			<input type="hidden" name="size" value="1000000">
		  <div class="form-group">
		    <label for="name">Franchisee Name<span style="color: red;">*</span></label>
		    <input type="text" class="form-control" name="frname" placeholder="Enter the name of franchisee" required>

		  </div>

		  <div class="form-group">
						    <label for="name"> Address (Line 1)<span style="color: red;">*</span></label>
						    <input type="text" class="form-control" id="nameofchild"  placeholder="Enter the address of the franchisee" name="line1" required>

				 </div>



		   
	            <div class="row">
	            	<div class="col-sm-6">
	            		 <div class="form-group">
						    <label for="name">City<span style="color: red;">*</span></label>
						    <input type="text" class="form-control" id="nameofchild"  placeholder="Enter the city of the franchisee" name="city" required>

						  </div>
		            	
		      		</div>

		      		  <div class="col-sm-6">
		      		  	  <div class="form-group">
						    <label for="name">Pin Code<span style="color: red;">*</span></label>
						    <input type="text" class="form-control" id="nameofchild"  placeholder="Enter the pin" name="pin" required>

						  </div>

		      		  
	      		  </div>	            	
	            </div>
	             
				 <div class="row">
	            	<div class="col-sm-6">
	            		 <div class="form-group">
						    <label for="name">Country<span style="color: red;">*</span></label>
						    
						    <select id="country" name ="country" class="form-control" id="sel1" ></select>
					    </div>
		            	
		      		</div>

		      		  <div class="col-sm-6">
		      		  	  <div class="form-group">
						    
						    <label for="name">State<span style="color: red;">*</span></label>
						  	<select name ="state" id ="state" class="form-control" id="sel1"></select>


						  </div>

		      		  
	      		  </div>	            	
	            </div>


		 
		 
		  <label for="program">Select your program<span style="color: red;">*</span></label>
		  <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="IIMTT">
		    <label class="form-check-label" for="exampleCheck1">IIMTT</label>

		  </div>
		  
		   <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="YLE">
		    <label class="form-check-label" for="exampleCheck1">YLE</label>

		  </div>
		   <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="MAXBRAIN">
		    <label class="form-check-label" for="exampleCheck1">MAXBRAIN</label>

		  </div>
		   <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="WRITO">
		    <label class="form-check-label" for="exampleCheck1">WRITO</label>

		  </div>
		   <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="3P">
		    <label class="form-check-label" for="exampleCheck1">3P</label>

		  </div>
		  <br>

		  <div class="row">
	            	<div class="col-sm-6">
	            		 <div class="form-group">
						    <label for="validform">Franchisee Valid From<span style="color: red;">*</span></label>
						    <input type="date" class="form-control" id="vto"  name="vfrom" required>

						  </div>
						            	
		      		</div>

		      		  <div class="col-sm-6">
		      		  	 <div class="form-group">
						    <label for="validform">Valid To<span style="color: red;">*</span></label>
						    <input type="date" class="form-control" id="vto"  name="vto" required>

						  </div>

		      		  
	      		  </div>	            	
	            </div>

		  
		  
		  <label for="validform">Upload Agreement Copy<span style="color: red;">*</span></label>
		  	 <br>

		  <div class="input-group">

			  <div class="input-group-prepend">
			    <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
			  </div>
			  <div class="custom-file">
			    <input type="file" class="custom-file-input" id="inputGroupFile01"
			      aria-describedby="inputGroupFileAddon01" name="image" required>
			    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
			  </div>
		</div>
		<br>

		 <div class="row">
	            	<div class="col-sm-6">
	            		  <div class="form-group">
						    <label for="number">Phone no.<span style="color: red;">*</span></label>
						    <input type="number" class="form-control" id="nameofchild"  placeholder="Enter the phn no." name="phn" required>
						     <small id="emailHelp" class="form-text text-muted">We'll never share your phone no. with anyone else.</small>

						  </div>
						            	
		      		</div>

		      		  <div class="col-sm-6">
		      		  	 <div class="form-group">
						    <label for="exampleInputEmail1">Email address<span style="color: red;">*</span></label>
						    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email" required>
						    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
						  </div>
		      		  
	      		  </div>	            	
	            </div>

	            <div class="row justify-content-center">
				  	<button type="submit" name="submit" class="btn btn-lg btn-block btn-success" style="margin-right: 20px; margin-left: 20px;">Submit</button>
				</div>
		  
		</form>
		
		<br>

	</div>
</div>
</div>
</div>
</div>

	<script type="text/javascript" src="/JS/countries.js"></script>

	<script>
// Add the following code if you want the name of the file appear on select
		$(".custom-file-input").on("change", function() {
		  var fileName = $(this).val().split("\\").pop();
		  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
		});
</script>

	 <script language="javascript">
			populateCountries("country", "state"); // first parameter is id of country drop-down and second parameter is id of state drop-down
			// populateCountries("country2");
			// populateCountries("country2");



		</script>
