<?php 



$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);

if(mysqli_connect_error()){
	die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}


$sql = "SELECT * FROM FRP_TB_FRANCHISE_LIST";

$result = mysqli_query($link,$sql);







?>

<div class="container">
	<div class="row">
        <div class="col-md-12">
          <h1 class="display-4">Franchise List</h1>
          <p class="lead text-muted">Welcome Admin</p>
          <!-- Dashboard Actions -->
          <div class="btn-group mb-4" role="group">
            <a href="registerFranchise" class="btn btn-success">
             Register New Franchisee</a>
            <a href="franchiseEdit" class="btn btn-primary">
             </i>
              Update an existing Franchise</a>
            <a href="deleteFranchise" class="btn btn-danger">
              </i>
              Delete Franchise</a>
          </div>
	<table class="table table-bordered table-hover ">
	  <thead class="thead-dark">
	    <tr>
	      <th scope="col">Serial No.</th>
	      <th scope="col">Franchise Name</th>
	      
	      <th scope="col">Country</th>
	      <th scope="col">State</th>
	      
	      <th scope="col">City</th>
	      <th scope="col">Program</th>
	      <th scope="col">Valid From</th>
	      <th scope="col">Valid To</th>
	      <th scope="col">Agrement Copy</th>
	      <th scope="col">Phone No.</th>
	      <th scope="col">Email Address</th>
	     
	      
	    </tr>
	  </thead>
	  <tbody>
	  	<?php 


	  		if($result){
				if(mysqli_num_rows($result)>0){
					while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
						$serial = $row['FRP_FRANCHISE_ID'];
						
						$fran_name = $row['FRAN_NAME'];
						$country = $row['COUNTRY'];
						$state = $row['STATE'];
						$city = $row['CITY'];
						$program = $row['PROGRAM'];
						$valid_from = $row['VALID_FROM'];
						$valid_to = $row['VALID_TO'];
						$agreement_copy = $row['AGREEMENT_COPY'];
						$phn_no = $row['PHN_NO'];
						$email = $row['EMAIL'];
						

						// if($itemPic){
						// 	$itemPic = "None";
						// }


						

						echo "<tr>
							      <td>$serial</td>
							      
							      <td>$fran_name</td>
							      <td>$country</td>
							      <td>$state</td>
							      <td>$city</td>
							      <td>$program</td>
							      <td>$valid_from</td>
							      <td>$valid_to</td>
							      <td>$agreement_copy</td>
							      <td>$phn_no</td>
							      <td>$email</td>
			 
							  </tr>";

					} 

				}else{
					echo '<div class="alert alert-danger">No Data</div>';
				}

			}else{
				echo '<div class="alert alert-danger">Error Running the Query</div>';
				echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
			}






	  	 ?>
	    
	    
	  </tbody>
	</table>
</div>
</div>
</div>
