<script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
</script>


<?php 
$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);
if(mysqli_connect_error()){
   die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}
	$dismissId = $_GET['dismisId'];

	if(!empty($dismissId)){
		$sql = "UPDATE BS_NOTIFICATION SET STATUS='DISMISSED' WHERE NOTIFICATION_ID='$dismissId'";
		$result = mysqli_query($link, $sql);

		if(!$result){
	          echo '<div class="alert alert-danger">There was a database error</div>';
	          echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
	         
	    }else{
	    	echo '<div class="alert alert-success">Dismissed the Notification</div>';


	}
	}
	



 ?>


 <div class="container">
 	<div class="col-sm-10 ml-auto mr-auto">
		<div class="tab-content" id="pills-tabContent">
			<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
				<div class="col-sm-12 border border-primary shadow rounded pt-2">
					<h3 style="text-align: center;">Notification Panel</h3>
				<div class="table-responsive">
		            	<table class="table table-bordered table-hover" id="taa">
						  <thead class="thead-dark">
						    <tr>
						      <th scope="col">Serial</th>
						      <th scope="col">Franchise</th>
						      <th scope="col">Details</th>
						      <th scope="col">Session</th>
						      <th scope="col">Subject</th>
						      <th scope="col">Action</th>
						      
						      
						    </tr>
						   </thead>
						    
						     	
						     
						      <tbody>
				<?php 
					$sql = "SELECT * FROM BS_NOTIFICATION WHERE STATUS = 'PENDING'";
					$result = mysqli_query($link, $sql);
					if ($result) {
					  if(mysqli_num_rows($result)>0){
					  	while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
					  		$id = $row["NOTIFICATION_ID"];
					  		$franchiseId = $row["USER_ID"];
						    $linkToGo = $row["LINK"];
						    $subDetails = $row["SUBJECT_DETAILS"];
						    $notificationDetails = $row["NOTIFICATION_DETAILS"];
						    $session = $row["SESSION"];
						    echo '		      	<tr>
												      <td>'.$id.'</td>
												    
												      <td>'.$franchiseId.'</td>
												      <td>'.$notificationDetails.'</td>
												      <td>'.$session.'</td>
												      <td>'.$subDetails.'</td>
												      
												      <td><div class="dropdown">
													  <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
													    
													  </button>
													  <div class="dropdown-menu">
													    <a class="dropdown-item" href="'.$linkToGo.'?userId='.$franchiseId.'&subject='.$subDetails.'&session='.$session.'">Upload Question</a>
													    <a class="dropdown-item" href="notification?dismisId='.$id.'">Dismiss</a>
													    
													  </div>
													</div></td>
												      
								 
												  </tr>

										      
								       ';
						    

					  	}
					    

					  }else{
					  	$GLOBALS['alert_info'] .= DaddToBsAlert("No Notification yet!");
					  }

					}
					if ($GLOBALS['alert_info']!="") {
				 		 echo $GLOBALS['alert_info'];
					}

				 ?>
				 </tbody>
			  </table>
			</div>
		</div>

	            

	        </div>

	    </div>
	</div>
</div>

 	


