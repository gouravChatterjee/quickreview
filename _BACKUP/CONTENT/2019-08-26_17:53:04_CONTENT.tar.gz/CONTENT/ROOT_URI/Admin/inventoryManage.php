
	<script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
  </script>
	<!-- <center> -->
<div class="container">
	<div class="d-flex justify-content-between bg-secondary mb-3">
	  <h1 class="display-5" style="color:#fff;">Inventory Management</h1>
	  <div class="btn-group mb-4" role="group">
	    <a href="?InventoryAdd" class="btn btn-success"> Add Inventory</a>
	    <a href="?InventoryOrder" class="btn btn-primary"> Order Inventory</a>
	    <a href="?InventoryIssue" class="btn btn-danger"> Issue Inventory</a>
	  </div>

	<!-- </center> -->
	</div>
</div>
<?php 
$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);
if(mysqli_connect_error()){
	die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}


 ?>

<?php if (isset($_GET)): ?>

	<?php if (isset($_GET['InventoryAdd'])): ?>
		 <?php  

	  	if ( isset($_POST["s_Hash"]) && $_POST["s_Hash"]== $_SESSION['s_Hash'] && isset($_POST["SubmitAdd"]) ) {
          if(isset($_POST['iBsnsName']) )
			$iBsnsName = $_POST['iBsnsName'];

		  if(empty($_POST['iNameNew'])){
		  	$iName = $_POST['iNameOld'];
		  }	else{
		  	$iName = $_POST['iNameNew'];
		  }


		  if(isset($_POST['iDescription']) )
			$iDescription = $_POST['iDescription'];
		if(isset($_POST['date']) )
			$date = $_POST['date'];
		if(isset($_POST['iNumber']) )
			$iNumber = $_POST['iNumber'];

		$sql = "INSERT INTO BS_INVENTORY (`PROGRAM_ID`, `ITEM_NAME`, `ITEM_DESC`, `ITEM_REC_DATE`,`NUMBER_OF_ITEMS`)VALUES('$iBsnsName', '$iName', '$iDescription', '$date','$iNumber')";
		$result = mysqli_query($link, $sql);
		if(!$result){
		// echo '<div class="alert alert-danger">There was a database error </div>';
		// echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
		$GLOBALS['alert_info'] .= DaddToBsAlert("Sorry Some error occured. Please try again");

		DreportLog("DB_CONNECT",mysqli_error($link),__FILE__);
		
		}else{
			
			$GLOBALS['alert_info'] .= DaddToBsAlert("Successfully added the inventory");
			}
		
 	}
        if ($GLOBALS['alert_info']!="") {
		  	echo $GLOBALS['alert_info'];
		}
        ?>
		
		<div id="registermsg"></div>
		<br>
		<h2 class="display-6 text-center" >Add Inventory</h2>
	  <div class="col-sm-8 ml-auto mr-auto">
	    <div class="tab-content" id="pills-tabContent">
	      <div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
	        <div class="col-sm-12 border border-primary shadow rounded pt-2">
	        	<script type="text/javascript">
	        		$(document).ready(function(){ 
	        		$('#bsns').change(function(){
	        			// console.log("hello");
						    $.ajax({
						        url: "/API/V1/?business",
						        data: { value: $("#bsns").val() },
						        dataType:"html",
						        type: "post",
						        success: function(data){
						        	// console.log(data);
						        	// var dd = data;
						        	// //console.log(dd);
						        	// console.log(typeof dd);
						        	// var tt = "yes";
						        	// if(dd == tt){
						        	// 	 console.log(dd);
						        	// 	$('#item').show();
						        	// }
						        	// 	$('#iGrp').empty().append(data);

						        	var res= jQuery.parseJSON(data);
						        	if(res.file){
						        		console.log(res.file);
						        	}else if(res.folder){
						        		console.log(res.folder);
						        	}
						        	
						           
						        }
						    });


						 //    axios({
							//   method: 'post',
							//   url: '/API/V1/?business',
							//   data: {
							//     value: $("#bsns").val()
							    
							//   },
							  
							// })
							//   .then(function (response) {
							//     console.log(response);
							//   });






						});
	        		$('#iGrp').change(function(){
	        			// console.log("hello");
						    $.ajax({
						        url: "/API/V1/?group",
						        data: { 
						        	bsns: $("#bsns").val(), 
						        	grp: $("#iGrp").val() 
						        },
						        dataType:"html",
						        type: "post",
						        success: function(data){
						        	console.log(data);
						           $('#pName').empty().append(data);
						        }
						    });
						});
	        	});



	        		function getGroup(val) {
	        			if(val != ""){
	        				
	        				alert(val);
	        			}
	        			
	        		}
	        	</script>
	          <form method="post">
							<div class="form-group">
								<input type="hidden" name="FormTarget" value=""><input type="hidden" name="s_Hash" value="<?php echo $_SESSION['s_Hash'] ?>">
								<label for="sel1"> Inventory for (Business name) &nbsp; </label>
								<select class="form-control" name="iBsnsName" id="bsns">
									<option value="">Select</option>
									<?php 
									$i=0;
							        foreach (glob("CONTENT/DATA/Structure/Business/*") as $filename) {
							          if(is_dir($filename)) {
							            $i++;
							            $FolderName=explode('/', $filename); $FolderName=end($FolderName);
							            echo "<option value='". $FolderName ."'>" .$FolderName ."</option>" ;
							            
							          }
							        }
									?>
									
								</select>
							</div>
	            <div class="row">
	            	<div class="col-sm-6">
		            	<div class="form-group" id="itemNameDrop">
			      		    <label for="name">Item Group </label>
			      		    <select name="iNameOld" class="form-control" id="iGrp">
			      		    	
							
							</select>
		      		  </div>
		      		</div>

		      		  <div class="col-sm-6">

		      		  <div class="form-group" id="programNameDrop">
			      		    <label for="name">Program Name</label>
			      		    <select name="iNameOld" class="form-control" id="pName">
			      		    	
							
							</select>
		      		  </div>




			      		 <!--  <div class="form-group" id="itemNew" style="display: none;">
			      		    <label for="name">Item Name</label>
			      		    <input type="text" class="form-control" placeholder="Enter the item Name" name="iNameNew">
			      		  </div> -->
	      		  </div>
	      		  
	      		<!-- <div class="col-sm-6">
	      			<div class="form-group" id="itemNameBtn">
	      				<label for="name">Add Item</label>
	      				
	      				<input type="button" class="btn btn-dark form-control" id="showBtn" value="Add New Item">
	      			</div>
	      			
	      		</div> -->
	            	
	            </div>

	             <div class="form-group" style="display: none;" id="item">
	      		    <label for="name">Item Name</label>
	      		    <select name="iNameOld" class="form-control" id="iName">
			      		    	<option>Hellooo</option>
							
							</select>
	      		    
	      		  </div>
	      		  
	            <div class="form-group">
	      		    <label for="name">Item Description</label>
	      		    <input type="text" class="form-control" placeholder="Enter the item Name" name="iDescription" required>
	      		  </div>
							<div class="row">
								<div class="col-sm-6">
								 <div class="form-group">
								 	<label for="itemNumber">Number of Items</label>
								 	<input type="number" name="iNumber" class="form-control" required placeholder="Enter the number of items">
								 	
								 </div>
							 </div>
							 <div class="col-sm-6">
								 <div class="form-group">
								 	<label for="dateofbirth">Date</label>
								 	<input type="text" id="datepicker" class="form-control" autocomplete="off" name="date" value="<?php echo date('Y-m-d'); ?>" required>
								 	
								 </div>
								</div>
								 
							 <!-- <div class="col-sm-6">
								<div class="form-group">
	 	       		    <label for="dateofbirth">Date (Set manually)</label>
	 	       		    <input type="date" class="form-control" name="iDate" >
	 	       		  </div>
							 </div> -->
							</div>

	            <input type="submit" class="btn btn-primary" name="SubmitAdd" value="Submit">
	          </form>
	          <br>
	        </div>
	      </div>
	    </div>
	  </div>

	<?php endif; ?>

	<?php if (isset($_GET['InventoryOrder'])): ?>
		<div id="registermsg"></div>
		<br>
		<h2 class="display-6 text-center" >Order Inventory</h2>
	  <div class="col-sm-8 ml-auto mr-auto">
	    <div class="tab-content" id="pills-tabContent">
	      <div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
	        <div class="col-sm-12 border border-primary shadow rounded pt-2">
	          <form method="post" >
	          	<div class="form-group">
								<input type="hidden" name="FormTarget" value=""><input type="hidden" name="s_Hash" value="<?php echo $_SESSION['s_Hash'] ?>">
								<label for="sel1"> Inventory for (Business name) &nbsp; </label>
								<select class="form-control" name="iBsnsName"  required>
									<?php 
									$i=0;
							        foreach (glob("CONTENT/DATA/Structure/Business/".$_GET['Business']."/".$_GET['Program']."/*") as $filename) {
							          if(is_dir($filename)) {
							            $i++;
							            $FolderName=explode('/', $filename); $FolderName=end($FolderName);
							            echo "<option value='". $FolderName ."'>" .$FolderName ."</option>" ;
							            
							          }
							        }
									?>
									
								</select>
							</div>
	            <div class="form-group">
	      		    <label for="name">Item Name </label>
	      		    <select name="iName" class="form-control">
					<?php

					$sql1 = "SELECT ITEM_NAME FROM BS_INVENTORY";

					$result1 = mysqli_query($link,$sql1);
					while ($row = mysqli_fetch_array($result1)){
					echo "<option value='". $row['ITEM_NAME'] ."'>" .$row['ITEM_NAME'] ."</option>" ;
					}
					?>
				</select>
	      		  </div>
							
	            <div class="form-group">
	      		    <label for="name">Number of Items</label>
	      		    <input type="number" class="form-control" placeholder="Enter the number of items" name="iNumber" required>
	      		  </div>
	      		  <div class="row">
							 <div class="col-sm-12">
								 <div class="form-group">
								 	<label for="dateofbirth">Date</label>
								 	<input type="text" id="datepicker" class="form-control" autocomplete="off" name="date" value="<?php echo date('Y-m-d'); ?>" required>
								 	
								 </div>
				  </div>
							
	            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
	          </form>
	          <br>
	        </div>
	      </div>
	    </div>
	  </div>
	<?php endif; ?>

	<?php if (isset($_GET['InventoryIssue'])): ?>
		<div id="registermsg"></div>
		<br>
		<h2 class="display-6 text-center" >Issue Inventory</h2>
	  <div class="col-sm-8 ml-auto mr-auto">
	    <div class="tab-content" id="pills-tabContent">
	      <div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
	        <div class="col-sm-12 border border-primary shadow rounded pt-2">
	          <form method="post" >

							<div class="form-group">
	      		   				<label for="name">Business Name</label> <br>
								<label class="radio-inline"><input type="radio" name="iBsName" checked>preschool</label>
								<label class="radio-inline"><input type="radio" name="iBsName">Teacher Training</label>
								<label class="radio-inline"><input type="radio" name="iBsName"> Afterschool Programme</label>

								<!-- <input type="text" class="form-control" placeholder="Enter the item Name" name="iName" required> -->
	      		  			</div>

							<div class="form-inline">
								<div class="form-group">
									  <label for="sel1"> issued to &nbsp; </label>
									  <select class="form-control" id="sel1" name="pid" onchange="$('#stID').remove();">
									    <option>Beanstalk</option>
									    <option>Franchisee 1</option>
									    <option>Franchisee 2</option>
									    <option>Franchisee 3</option>
									    <option>Franchisee 4</option>
									  </select>
								</div>
								<div class="form-group" id="stID">
									<label for="name"> &nbsp; &nbsp; Student id &nbsp; &nbsp;  </label>
									<input type="text" class="form-control" placeholder="Enter the Student ID" name="iDescription" required>
								</div>
							</div>
							<br>

							<div class="row">
								<div class="col-sm-6">
								 <div class="form-group">
								 	<label for="itemNumber">Number of Items</label>
								 	<input type="number" name="iNumber" class="form-control" required placeholder="Enter the number of items">
								 	
								 </div>
							 </div>
							 <div class="col-sm-6">
								 <div class="form-group">
								 	<label for="dateofbirth">Date</label>
								 	<input type="text" id="datepicker" class="form-control" autocomplete="off" name="date" value="<?php echo date('Y-m-d'); ?>" required>
								 	
								 </div>
								</div>
								 
							 <!-- <div class="col-sm-6">
								<div class="form-group">
	 	       		    <label for="dateofbirth">Date (Set manually)</label>
	 	       		    <input type="date" class="form-control" name="iDate" >
	 	       		  </div>
							 </div> -->
							</div>








							<!-- <div class="row">
							 <div class="col-sm-6">
								 <div class="form-group">
								 	<label for="dateofbirth">Date (Today)</label>
								 	<input type="text" class="form-control" name="iDate" value="" required>
								 </div>
							 </div>
							 <div class="col-sm-6">
								<div class="form-group">
	 	       		    <label for="dateofbirth">Date (Set manually)</label>
	 	       		    <input type="date" class="form-control" name="iDate" >
	 	       		  </div>
							 </div>
							</div> -->
	            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
	          </form>
	          <br>
	        </div>
	      </div>
	    </div>
	  </div>
	<?php endif; ?>


<?php endif; ?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
				<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

				<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/jquery-ui.js"></script>




<script>

  $(document).ready(function(){
	     $("#datepicker").datepicker({
	     	maxDate: "+3M +10D",
	     	showAnim:"drop",
	     	dateFormat:"yy-mm-dd"
	     });

	     
	});

  $("#showBtn").click(function(){
  $("#itemNameDrop").toggle();
  $("#itemNew").toggle();
  $(this).val( $(this).val() == 'Add New Item' ? 'Add Existing Item' : 'Add New Item' );
  // $("#itemNew").toggle();
	});


function getType() {

var bs = document.getElementById("bsns");
var carSelected = bs.options[bs.selectedIndex].value;
console.log(carSelected);
<?php
	$after = "Afterschool Program";
	$path = "CONTENT/DATA/Structure/Business/".$after."/*";
	foreach (glob("CONTENT/DATA/Structure/Business/".$after."/*") as $filename) {
      if(is_dir($filename)) {

        $FolderName=explode('/', $filename); $FolderName=end($FolderName);
        $GLOBALS['folder'] += $FolderName;

	            
       
      }	
    } 
    ?>




  // var x = document.getElementById("food").value;
  // var items;
  // if (x === "fruit") {
  //   items = ["Apple", "Oranges", "Bananas"];
  // } else {
  //   items = ["Eggplants", "Olives"]
  // }
  var items = "<?php echo $GLOBALS['folder']; ?>"
  var str = ""
  for (var item of items) {
    str += "<option>" + item + "</option>"
  }
  document.getElementById("iGrp").innerHTML = str;
}
// document.getElementById("btn").addEventListener("click", getType)




</script>
