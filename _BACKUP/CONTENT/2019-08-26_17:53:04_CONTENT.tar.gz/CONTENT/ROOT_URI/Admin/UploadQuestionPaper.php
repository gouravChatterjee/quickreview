<script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
 </script>


<?php 
$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);

if(mysqli_connect_error()){
	die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}

$userId = $_GET['userId'];
$subject = $_GET['subject'];
$session = $_GET['session'];




if($_FILES["quesFile"]["name"]) {
	$question = $_FILES['quesFile']['name'];
	
	mkdir("CONTENT/UPLOADS/FRANCHISE/".$userId."/InternalQuestion/".$session."/".$subject,  0755, true);
	$target = "CONTENT/UPLOADS/FRANCHISE/".$userId."/InternalQuestion/".$session."/".$subject."/".basename($question);
	if (move_uploaded_file($_FILES['quesFile']['tmp_name'], $target)) {
  		$GLOBALS['alert_info'] .= DaddToBsAlert("Question Paper uploaded successfully!!");
  		// echo "uploaded";
  	}else{
  		$GLOBALS['alert_info'] .= DaddToBsAlert("Could not upload question paper!! Try Again!");
  		// echo "not uploaded";
  	}

	

}
if ($GLOBALS['alert_info']!="") {
  echo $GLOBALS['alert_info'];
}



 ?>

 <div class="container">
 	<div class="col-sm-10 ml-auto mr-auto">
		<div class="tab-content" id="pills-tabContent">
			<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
				<div class="col-sm-12 border border-primary shadow rounded pt-2">
					<div class="table-responsive">
		            	<table class="table table-bordered table-hover" id="taa">
						  <thead class="thead-dark">
							    <tr>
							      
							      <th scope="col">Franchise Id</th>
							     
							      <th scope="col">Subject Id</th>
							      <th scope="col">Action</th>
							     </tr>
						    </thead>
						    
						     	
						     
						      <tbody>
						      	<?php 
						      		echo "<tr>
										      <td>$userId</td>
										      
										      <td>$subject</td>
										      <form method='POST' enctype='multipart/form-data'>
										     
										      <td><input type='file' name='quesFile' onclick='change();' />";
										     
										      $files = glob("CONTENT/UPLOADS/FRANCHISE/".$userId."/InternalQuestion/".$session."/".$subject."/*");
										      if (count($files) > 0){
										      
										      	echo '<a href="/'.$files[0].'"  class="btn btn-primary" download><i class="fa fa-download"></i> Download</a>' ;
										     	$text = "Replace";
										      }else{
										     	$text = "Upload";
										     }
												
										     
										     echo "<button type='submit' id='sub' class='btn btn-success' name='submit' value=$prId><i class='fa fa-upload'></i> $text</button>

										     
										     
										      </td>

										      </form>

										      
										      
										  </tr>";


						      	 ?>
						      </tbody>
						  </table>
				    </div>
				</div>
			</div>
		</div>
	</div>
</div>

