<?php 

$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);
if(mysqli_connect_error()){
	die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}

if (isset($_POST['upload'])){




	if(isset($_POST['pid']) )
		$pid = $_POST['pid'];


	if(isset($_POST['pdesc']))
		$pdesc = $_POST['pdesc'];
	if(isset($_POST['itemid']))
		$itemid = $_POST['itemid'];
	if(isset($_POST['itemdesc']))
		$itemdesc = $_POST['itemdesc'];
	if(isset($_POST['itemdesc']))
		$itemdesc = $_POST['itemdesc'];

	
	$image = $_FILES['image']['name'];
	
	if(isset($_POST['cost']))
		$cost = $_POST['cost'];

	$itemid = mysqli_real_escape_string($link,$itemid);
	$itemdesc = mysqli_real_escape_string($link,$itemdesc);
	$cost = mysqli_real_escape_string($link,$cost);

	$target = "././uploads/bookImages/".basename($image);
	$sql = "INSERT INTO FRP_TB_BOOK_COST (`PROGRAM_ID`, `PROGRAM_DESCR`, `ITEM_ID`, `ITEM_DESCR`, `IMAGE`, `COST`)VALUES('$pid', '$pdesc', '$itemid', '$itemdesc', '$image', '$cost')";

	$result = mysqli_query($link, $sql);
	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  		// echo "uploaded";
  	}else{
  		$msg = "Failed to upload image";
  		// echo "not uploaded";
  	}

  	if(!$result){
		echo '<div class="alert alert-danger">There was a database error </div>';
		// echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
		DreportLog("DB_CONNECT",mysqli_error($link),__FILE__);
		
	}else{
		
		header('Location: bookCostShow');
		

		
	}

}




?>

<div class="container">
	<h1 class="display-4">NEW BOOK COST</h1>
	<form action="bookCostAdd" method="POST" enctype="multipart/form-data">
		 
		    <input type="hidden" name="size" value="1000000">

			<div class="form-group">
			  <label for="sel1">Program ID</label>
			  <select class="form-control" id="sel1" name="pid">
			    <option>TT1</option>
			    <option>YLE</option>
			    <option>MAX</option>
			    <option>WRT</option>
			    <option>3P</option>
			  </select>
			</div>

			<div class="form-group">
			  <label for="sel1">Program Desc</label>
			  <select class="form-control" id="sel1" name="pdesc">
			    <option>IIMTT</option>
			    <option>YLE</option>
			    <option>MAXBRAIN</option>
			    <option>WRITO</option>
			    <option>3P</option>
			  </select>
			</div>

			<div class="form-group">
			  <label for="sel1">Item ID</label>
			  <select class="form-control" id="sel1" name="itemid">
			    <option>TT1</option>
			    <option>YLE1</option>
			    <option>YLE2</option>
			    <option>YLE3</option>
			    <option>YLE4</option>
			    <option>YLE5</option>
			    <option>YLE6</option>
			    <option>YLE7</option>
			    <option>YLE8</option>
			    <option>YLE9</option>
			    <option>MAX1</option>
			    <option>MAX2</option>
			    <option>MAX3</option>
			    <option>MAX4</option>
			    <option>MAX5</option>
			    <option>MAX6</option>
			    <option>A-WR1</option>
			    <option>A-WR2</option>
			    <option>A-WR3</option>
			    <option>A-WR4</option>
			    <option>SP1</option>
			    <option>SP2</option>
			    <option>SP3</option>
			     <option>P-WR1</option>
			     <option>P-WR2</option>
			     <option>P-WR3</option>
			     <option>MIN1</option>
			     <option>MIN2</option>
			     <option>MIN3</option>
			  </select>
			</div>
		   
		 
		  <div class="form-group">
		    <label for="item">Item Description</label>
		    <input type="text" class="form-control" id="itm" name="itemdesc" placeholder="Item Description">
		   
		  </div>

		  <label for="upload">Upload Picture</label>
		  	 <br>

		  <div class="input-group">

			  <div class="input-group-prepend">
			    <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
			  </div>
			  <div class="custom-file">
			    <input type="file" class="custom-file-input" id="inputGroupFile01"
			      aria-describedby="inputGroupFileAddon01" name="image">
			    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
			  </div>
		</div>
		<br>
		  
		   
		   
		  

		


		  

		  <div class="form-group">
		    <label for="number">Cost (Excluded GST)</label>
		    <input type="number" class="form-control" id="tenure"  placeholder="Book Cost" name="cost">
		   
		  </div>

		  

		  


		  

		  



		  
		  
		  <button type="submit" class="btn btn-success btn-lg" name="upload"> Add</button>
		</form>
		<br>
		<br>



		<script>
// Add the following code if you want the name of the file appear on select
$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});
</script>



</div>