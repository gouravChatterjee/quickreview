



<footer class="footer" style="background-color: #99AAAB; position: relative; left: 0; bottom: 0;  width: 100%; margin-top: 15px;">
	<div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="https://beanstalkedu.com/"> Beanstalkedu Services Pvt Ltd.</a>
  </div>

</footer>

  </body>

</html>
