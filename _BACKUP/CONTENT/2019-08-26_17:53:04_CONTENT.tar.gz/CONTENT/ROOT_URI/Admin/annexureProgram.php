<?php 



$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);

if(mysqli_connect_error()){
	die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}


$sql = "SELECT * FROM FRP_TB_ANNEXURE_PROGRAM";

$result = mysqli_query($link,$sql);







?>

<div class="container">
	<div class="row">
        <div class="col-md-12">
          <h1 class="display-4">ANNEXURE : PROGRAM & ITEM MASTER</h1>
          <p class="lead text-muted">Welcome Admin</p>
          <!-- Dashboard Actions -->
          <div class="btn-group mb-4" role="group">
            <a href="addProgram" class="btn btn-success">
             Add Program</a>
            <a href="editProgram" class="btn btn-primary">
             </i>
              Edit Program</a>
            <a href="deleteProgram" class="btn btn-danger">
              </i>
              Delete Program</a>
          </div>
	<table class="table table-bordered table-hover ">
	  <thead class="thead-dark">
	    <tr>
	      <th scope="col">Serial Number</th>
	      <th scope="col">Program</th>
	      <th scope="col">Program Id</th>
	      <th scope="col">Item Id</th>
	      <th scope="col">Item Desc</th>
	      <th scope="col">Item pic</th>
	      <th scope="col">Level</th>
	      <th scope="col">Tenure</th>
	      <th scope="col">Business Vertical</th>
	      <th scope="col">Item QR Code</th>
	      
	    </tr>
	  </thead>
	  <tbody>
	  	<?php 


	  		if($result){
				if(mysqli_num_rows($result)>0){
					while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
						$serial = $row['FRP_AP_ID'];
						$program = $row['PROGRAM'];
						$programId = $row['PROGRAM_ID'];
						$itemId = $row['ITEM_ID'];
						$itemDesc = $row['ITEM_DESC'];
						$itemPic = $row['ITEM_PIC'];
						$level = $row['LEVEL'];
						$tenure = $row['TENURE'];
						$bsnsV = $row['BUSINESS_VERTICAL'];
						$qrCode = $row['QR_CODE_ITEM'];

						// if($itemPic){
						// 	$itemPic = "None";
						// }


						

						echo "<tr>
							      <td>$serial</td>
							      <td>$program</td>
							      <td>$programId</td>
							      <td>$itemId</td>
							      <td>$itemDesc</td>
							      <td>$itemPic</td>
							      <td>$level</td>
							      <td>$tenure</td>
							      <td>$bsnsV</td>
							      <td>$qrCode</td>
							  </tr>";

					} 

				}else{
					echo '<div class="alert alert-danger">No Data</div>';
				}

			}else{
				echo '<div class="alert alert-danger">Error Running the Query</div>';
				echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
			}






	  	 ?>
	    
	    
	  </tbody>
	</table>
</div>
</div>
</div>
