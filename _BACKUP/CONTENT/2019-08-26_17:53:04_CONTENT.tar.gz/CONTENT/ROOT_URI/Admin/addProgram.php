<?php 

// include('connection.php');

$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);
if(mysqli_connect_error()){
	die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}
if (isset($_POST['submit'])){
	if(isset($_POST['program']) )
		$program = $_POST['program'];


	if(isset($_POST['programId']))
		$programId = $_POST['programId'];
	if(isset($_POST['itemid']))
		$itemid = $_POST['itemid'];
	if(isset($_POST['itemdesc']))
		$itemdesc = $_POST['itemdesc'];
	

	$image = $_FILES['image']['name'];
	if(isset($_POST['level']))
		$level = $_POST['level'];
	if(isset($_POST['tenure']))
		$tenure = $_POST['tenure'];
	if(isset($_POST['bsnsVer']))
		$bsnsVer = $_POST['bsnsVer'];


	$target = APP_PATH."/uploads/program/".basename($image);

	$sql = "INSERT INTO FRP_TB_ANNEXURE_PROGRAM (`PROGRAM`,`PROGRAM_ID`, `ITEM_ID`, `ITEM_DESC`, `ITEM_PIC`, `LEVEL`,`TENURE`,`BUSINESS_VERTICAL`)VALUES('$program', '$programId', '$itemid', '$itemdesc', '$image', '$level','$tenure','$bsnsVer')";

	$result = mysqli_query($link, $sql);
	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  		// echo "uploaded";
  	}else{
  		$msg = "Failed to upload image";
  		// echo "not uploaded";
  	}
  	if(!$result){
		echo '<div class="alert alert-danger">There was a database error </div>';
		echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
		DreportLog("DB_CONNECT",mysqli_error($link),__FILE__);
		
	}else{
		
		header('Location: annexureProgram');
		

		
	}



}



?>

<div class="container">
	<h1 class="display-4">ADD NEW PROGRAM</h1>
	<form method="POST" enctype="multipart/form-data">
		<input type="hidden" name="size" value="1000000">
		 
		    <div class="form-group">
			  <label for="sel1">Program</label>
			  <input type="text" class="form-control" id="itm" name="program" placeholder="Program Name" required>
		   
			</div>

			<div class="form-group">
			  <label for="sel1">Program ID</label>
			  <input type="text" class="form-control" id="itm" name="programId" placeholder="Program ID" required>
			</div>

			<div class="form-group">
			  <label for="sel1">Item ID</label>
			  <input type="text" class="form-control" id="itm" name="itemid" placeholder="Item Id" required>
			 <!--  <select class="form-control" id="sel1">
			    <option>TT1</option>
			    <option>YLE1</option>
			    <option>YLE2</option>
			    <option>YLE3</option>
			    <option>YLE4</option>
			    <option>YLE5</option>
			    <option>YLE6</option>
			    <option>YLE7</option>
			    <option>YLE8</option>
			    <option>YLE9</option>
			    <option>MAX1</option>
			    <option>MAX2</option>
			    <option>MAX3</option>
			    <option>MAX4</option>
			    <option>MAX5</option>
			    <option>MAX6</option>
			    <option>A-WR1</option>
			    <option>A-WR2</option>
			    <option>A-WR3</option>
			    <option>A-WR4</option>
			    <option>SP1</option>
			    <option>SP2</option>
			    <option>SP3</option>
			     <option>P-WR1</option>
			     <option>P-WR2</option>
			     <option>P-WR3</option>
			     <option>MIN1</option>
			     <option>MIN2</option>
			     <option>MIN3</option>
			  </select> -->
			</div>
		   
		 
		  <div class="form-group">
		    <label for="name">Item Description</label>
		    <input type="text" class="form-control" id="item" name="itemdesc" placeholder="Item Description" required>
		   
		  </div>

		  <label for="validform">Upload Item Pic</label>
		  	 <br>

		  <div class="input-group">

			  <div class="input-group-prepend">
			    <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
			  </div>
			  <div class="custom-file">
			    <input type="file" class="custom-file-input" id="inputGroupFile01"
			      aria-describedby="inputGroupFileAddon01" name="image">
			    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
			  </div>
		</div>
		<br>
		  
		   
		   
		  

		<div class="form-group">
			  <label for="sel1">Level</label>
			  <input type="text" class="form-control" id="item" name="level" placeholder="Level" required>
			</div>


		  

		  <div class="form-group">
		    <label for="number">Tenure</label>
		    <input type="number" class="form-control" id="tenure"  placeholder="Tenure(Months)" name="tenure" required>
		   
		  </div>

		  <div class="form-group">
		    <label for="name">Business Vertical</label>
		    <input type="text" class="form-control" id="bsns" name="bsnsVer" placeholder="Business Vertical" required>
		   
		  </div>

		  


		  

		  



		  
		  
		  <button type="submit" class="btn btn-success" name="submit">Submit</button>
		</form>
		<br>
		<br>



		<script>
// Add the following code if you want the name of the file appear on select
$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});
</script>



</div>