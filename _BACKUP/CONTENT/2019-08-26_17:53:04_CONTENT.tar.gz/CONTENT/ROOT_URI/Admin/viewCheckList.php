<div class="container">

<div class="col-sm-12 ml-auto mr-auto">
	<div class="tab-content" id="pills-tabContent">
		<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
            <div class="col-sm-12  border border-primary shadow rounded pt-2">
            	<h1 style="text-align: center;">Franchise Joining Check List</h1>
            	<hr>
            </div>
        </div>
    </div>
</div>