

<?php

 $db = mysqli_connect("localhost", "root", "", "beanstalkfp");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$file = $_FILES['file']['name'];
  	// Get text
  	// $image_text = mysqli_real_escape_string($db, $_POST['image_text']);

  	// image file directory
  	$target = "uploads/".basename($file);

  	$sql = "INSERT INTO upload_file (file, text) VALUES ('$file', 'hello')";
  	// execute query
  	mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
  		$msg = "File uploaded successfully";
  	}else{
  		$msg = "Failed to upload file";
  	}
  }
  $result = mysqli_query($db, "SELECT * FROM upload_file");




 ?>

 <!-- <form class="form-inline" method="post">
   <div class="form-group">
     <input type="file" class="custom-file-input" id="customFile">
   </div>
   <div class="form-group">
     <label class="custom-file-label" for="customFile">Choose file</label>
   </div>

   <button type="submit" class="btn btn-warning">Submit</button>
 </form> -->
 <br>
 <br>
 <br>
<div class="container">
	<form method="post" action="upload" enctype="multipart/form-data">
		<div class="row">
			<input type="hidden" name="size" value="1000000">
			<div class="col-sm-10">

  				
				<input type="file" class="custom-file-input" id="customFile" name="file">
				<label class="custom-file-label" for="customFile">Choose file</label>
			</div>
			<div class="col-sm-2">
				<button type="submit" class="btn btn-warning" name="upload">Submit</button>
			</div>
		</div>
<!--
		<div class="custom-file">
			<input type="file" class="custom-file-input" id="customFile">
			<label class="custom-file-label" for="customFile">Choose file</label>
		</div> -->
	</form>
	<script>
// Add the following code if you want the name of the file appear on select
$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});
</script>
</div>
