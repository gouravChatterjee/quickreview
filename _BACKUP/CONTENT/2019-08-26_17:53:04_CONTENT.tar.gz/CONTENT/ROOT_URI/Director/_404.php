<div class="DCenterAll">
  <span style='font-size:100px;'>&#9846; &#9762; &#9846;</span>
  <h3 class="text-center">404 - Page not found</h3>
</div>
