<script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
</script>





<?php 
   $link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);
   $email = $_SESSION["user"];

   $sql = "SELECT * FROM BS_USER WHERE USER_EMAIL = '$email'";

   $result = mysqli_query($link,$sql);

   if($result){
        if(mysqli_num_rows($result)>0){
         $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
         $fullName = $row["USER_FULL_NAME"];
         $type = $row["BS_USER_TYPE"];
         $phn = $row["USER_PHONE"];
         $email = $row["USER_EMAIL"];
        }
    }





?>




<?php if ($_SESSION['LoggedIn']): ?>

<div class="dashboard">


    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 class="display-4">Dashboard</h1>
          <p class="lead text-muted">Welcome <?php echo $fullName; ?></p>
          <!-- Dashboard Actions -->
          <div class="btn-group mb-4" role="group">
            <a href="#" class="btn btn-light" href="javascript:;" data-toggle="modal" data-target="#changePass">
              <i class="fas fa-user-circle text-info mr-1"></i> Change Password</a>
            
          </div>

          <!-- Experience -->
          <div>
            <h4 class="mb-2">User Details</h4>
            <table class="table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Role</th>
                  <th>Email</th>
                  <th>Phone No.</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><?php echo $fullName; ?></td>
                  <td><?php echo $type; ?></td>
                  <td>
                   <?php echo $email; ?>
                  </td>
                  <td>
                   <?php echo $phn; ?>
                  </td>
                  
                </tr>
                
              </tbody>
            </table>
          </div>

          <!-- Education -->
          

        </div>
      </div>
    </div>
    <div class="modal fade" id="changePass" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form method="post" id="forgotpassForm">
                <input type="hidden" name="s_Hash" value="<?php echo $_SESSION['s_Hash']; ?>">
                <input type="hidden" name="FORM_NAME" value="changePasswordForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Change Password</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="font-weight-bold">New Password <span class="text-danger">*</span></label>
                            <input type="password" name="password1" id="password_1" class="form-control" placeholder="***********" pattern="^\S{6,}$" onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Must have at least 6 characters' : ''); if(this.checkValidity()) form.password_two.pattern = this.value;" required>
                        </div>
                        <div class="form-group">
                            <label class="font-weight-bold">Confirm Password <span class="text-danger">*</span></label>
                            <input type="password" name="password2" id="password_2" class="form-control" pattern="^\S{6,}$" onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Please enter the same Password as above' : '');" placeholder="***********" required>
                        </div>
                        <div class="form-group">
                        </div>
                    </div>
                    <div class="modal-footer">
                      
                        <button type="submit" name="sendMail" class="btn btn-primary"> Send Request</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
  </div>
  <br><br><br><br><br><br><br>

        <?php else: ?>
          <h1>You are not authorized</h1>
          <h4>Please Log in <a href="/sign">here</a></h4>
          
  <?php endif; ?>