<?php
$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);
if(mysqli_connect_error()){
   die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}
  if(isset($_SESSION['user']))
{
  $email = $_SESSION['user'];
  $sql = "SELECT * FROM BS_USER WHERE USER_EMAIL = '$email'";
  $result = mysqli_query($link,$sql);
    if ($result) {
      if(mysqli_num_rows($result)>0){
        $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
        $json = $row['USER_JSOND'];
        $arr = json_decode($json, true);
        foreach($arr as $key=>$value){
          // echo $key."\n";
          foreach ($value as $ke => $val) {

            if ($ke == "Programs") {

              $programs = explode(',',$val);
              if (in_array("IIMTT", $programs))
              {
                $iimtt = true;
              }

            if (in_array("YLE", $programs) || in_array("MAXBRAIN", $programs) || in_array("WRITO", $programs) || in_array("3P", $programs))
            {
              $non_iimtt = true;
            }

            }


          }

        }
      }



    }
}
 ?>







<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="/CSS/DIZ.css" >
    <link rel="stylesheet" href="/CSS/style.css" >
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- <link rel="stylesheet" href="/CSS/video.css" > -->

    <!-- <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> -->
    <!-- <script src="https://kit.fontawesome.com/e1f2cafe0a.js"></script> -->
    <script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="  crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <title>BeansTalk Franchisee portal</title>
    <style type="text/css">
       .navbar .collapse .nav-item .nav-link{
        color: white;
        font-size: 18px;
     }

    .navbar-nav li:hover > ul.dropdown-menu {
      display: block;
    }
    .dropdown-submenu {
        position:relative;
    }
    .dropdown-submenu>.dropdown-menu {
        top:0;
        left:100%;
        margin-top:-6px;
    }

    /* rotate caret on hover */
    .dropdown-menu > li > a:hover:after {
        text-decoration: underline;
        transform: rotate(-90deg);
    }


    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-md navbar-light mb-4" style="background-color: #6AB04A;">
      <a class="navbar-brand pb-2" href="/"><img width="130px" height="40px"src="/IMAGES/logo.png" style="position:relative;top:-5px"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <?php if ($_SESSION['LoggedIn']): ?>
        <ul class="navbar-nav mr-auto">
           <li class="nav-item">
              <a class="nav-link" href="video">Training</a>

            </li>
           <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Administration
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                 <li class="nav-item">
                     <a class="dropdown-item" href="joiningCheckList">Joining Check List</a>
                </li>
                <li class="nav-item">
                     <a class="dropdown-item" href="franchiseInventory">Inventory</a>
                </li>
                <li class="dropdown-submenu"><a class="dropdown-item dropdown-toggle" href="#">Students Control</a>
                    <ul class="dropdown-menu">
                      <?php if ($iimtt && $non_iimtt): ?>
                      <li class="dropdown-submenu"><a class="dropdown-item dropdown-toggle" href="#">Students List</a>
                        <ul class="dropdown-menu">
                           <li><a class="dropdown-item" href="StudentListIIMTT">IIMTT Students</a></li>
                           <li><a class="dropdown-item" href="StudentListNonIIMTT">NON-IIMTT Students</a></li>
                        </ul>
                      </li>
                      <?php elseif ($iimtt): ?>
                        <li><a class="dropdown-item" href="StudentListIIMTT">Students List</a></li>
                      <?php else: ?>
                        <li><a class="dropdown-item" href="StudentListNonIIMTT">Students List</a></li>
                       <?php endif; ?>
                      <li> <a class="dropdown-item" href="registerStudents">Register Students</a></li>
                    </ul>
                  </li>

               <!--  <li><a class="dropdown-item" href="#">Another action</a></li> -->

              </ul>


       </li>
        <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Evaluation
              </a>
              <?php if ($iimtt && $non_iimtt): ?>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                 <li class="dropdown-submenu"><a class="dropdown-item dropdown-toggle" href="#">IIMTT</a>
                    <ul class="dropdown-menu">
                      <li><a class="dropdown-item" href="ExamControl">Exam Control</a></li>
                      <li><a class="dropdown-item" href="ExamMarks?studentSelection">Marksheet</a></li>
                    </ul>
                  </li>
                  <li class="dropdown-submenu"><a class="dropdown-item dropdown-toggle" href="#">NON-IIMTT</a>
                    <ul class="dropdown-menu">
                      <li><a class="dropdown-item" href="certificate">Certificate</a></li>
                    </ul>
                  </li>

               <!--  <li><a class="dropdown-item" href="#">Another action</a></li> -->

              </ul>
              <?php elseif ($iimtt): ?>
               <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <li class="nav-item">
                       <a class="dropdown-item" href="ExamControl">Exam Control</a>
                  </li>
                  <li class="nav-item">
                       <a class="dropdown-item" href="ExamMarks">Marksheet</a>
                  </li>

              </ul>


              <?php else: ?>
                 <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <li class="nav-item">
                         <a class="dropdown-item" href="certificate">Certificate Dashboard</a>
                    </li>

                </ul>
                <?php endif; ?>

       </li>


    </ul>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="fas fa-user"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                   <li class="nav-item">
                       <a class="dropdown-item" href="profile">Profile</a>
                  </li>
                  <li class="nav-item">
                       <a class="dropdown-item" href="/signOut">Sign Out</a>
                  </li>

                </ul>


         </li>

        </ul>
         <?php endif; ?>
         <?php if (!$_SESSION['LoggedIn']): ?>
            <ul class="navbar-nav ml-auto">
              <li class="nav-item pull-right">
                <a class="nav-link" href="/sign">Sign In</a>
              </li>
          </ul>
          <?php endif; ?>
  </div>
</nav>
