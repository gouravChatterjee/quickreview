<?php 
	$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);

	if(mysqli_connect_error()){
		die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
	}
	$studentId = $_GET['id'];
  $nonStudentId = $_GET['nonId'];

	if(!empty($_GET['id'])) {
      $sql="DELETE FROM FRP_TB_STUDENT_REGISTER WHERE FRP_STUDENT_ID='$studentId'";
      $result = mysqli_query($link, $sql);
       if(!$result){
          echo '<div class="alert alert-danger">There was a database error </div>';
          echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
          exit;
        }if($result){
          

             echo '<div class="alert alert-success" style="text-align:center; ">Successfully Deleted </div>';
              echo "
                        <script>
                        
                          window.location.href='StudentListIIMTT';
                        </script>
                        ";
            }


    }
    if (!empty($_GET['nonId'])) {
      $sql="DELETE FROM FRP_TB_NON_STUDENT_REGISTER WHERE FRP_NON_STUDENT_ID='$nonStudentId'";
      $result = mysqli_query($link, $sql);
       if(!$result){
          echo '<div class="alert alert-danger">There was a database error </div>';
          echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
          exit;
        }if($result){
          

             echo '<div class="alert alert-success" style="text-align:center; ">Successfully Deleted </div>';
              echo "
                        <script>
                        
                         window.location.href='StudentListNonIIMTT';
                        </script>
                        ";
            }

    }




 ?>