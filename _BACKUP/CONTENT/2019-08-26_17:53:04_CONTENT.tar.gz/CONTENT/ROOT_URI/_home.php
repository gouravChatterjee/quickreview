<div class="container">
	
			
		<h1 class="display-4" style="text-align: center;">Beanstalk Edu Services Pvt. Ltd.</h1>
		<h3 style="text-align: center;">Franchise Portal</h3>
		<hr>
		<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="width: 60%; height: 40%; margin: 0 auto">
			  <ol class="carousel-indicators">
			    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
			    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
			    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
			  </ol>
			  <div class="carousel-inner">
			    <div class="carousel-item active">
			      <img class="d-block w-100" src="/IMAGES/max.jpg" alt="First slide">
			    </div>
			    <div class="carousel-item">
			      <img class="d-block w-100" src="/IMAGES/slide2.jpg" alt="Second slide">
			    </div>
			    <div class="carousel-item">
			      <img class="d-block w-100" src="/IMAGES/slide3.jpg" alt="Third slide">
			    </div>
			  </div>
			  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
			    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
			    <span class="sr-only">Previous</span>
			  </a>
			  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
			    <span class="carousel-control-next-icon" aria-hidden="true"></span>
			    <span class="sr-only">Next</span>
			  </a>
		</div>
		<hr>

		<h3 style="text-align: center;">About This Portal</h3>
		 <div class="tab-content" id="pills-tabContent">
         	<div class="col-sm-10 ml-auto mr-auto">
            <div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
                <div class="col-sm-12 border border-primary shadow rounded pt-2">
                	<p class="lead" style="text-align: center;">This portal is for Franchise Holders, Admin and Director. If you are a franchise holder then this is the platform where you can control your all activities. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                	tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                	quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                	consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                	cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                	proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
            </div>
        </div>
    </div>
  		
			
		
		
		
	
</div>
<br>