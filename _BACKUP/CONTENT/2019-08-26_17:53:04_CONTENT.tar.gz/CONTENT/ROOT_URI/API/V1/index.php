<?php 


if (isset($_GET['business'])) {
		// echo "hello";	
	$bsns =  $_POST['value'];
	// echo '<option value="">Select</option>';
	// echo $bsns;

	// echo glob("CONTENT/DATA/Structure/Business/*");
	foreach (glob("CONTENT/DATA/Structure/Business/".$bsns."/*") as $filename) {
		// echo $fileName;
		if(is_file($filename)){
			$response=array('file'=>'yes', // First Value
				   );
					echo json_encode($response);
						// $filePresent = "yes";
						// echo $filePresent;
						exit();


					}
	          if(is_dir($filename)) {
	            $i++;
	            $FolderName=explode('/', $filename); $FolderName=end($FolderName);
	            // echo $FolderName;
	            $response=array('folder'=>$FolderName, // First Value
				   );
					echo json_encode($response);
	            // echo "<option value='". $FolderName ."'>" .$FolderName ."</option>" ;
	            
	          }
	        }
		}

		if (isset($_GET['group'])) {
		// echo "hello";	
			$bsns =  $_POST['bsns'];
			$group =  $_POST['grp'];
			echo '<option value="">Select</option>';
			// echo $bsns;
			// echo $group;

			// echo glob("CONTENT/DATA/Structure/Business/*");


			foreach (glob("CONTENT/DATA/Structure/Business/".$bsns."/".$group."/*") as $folder) {

				// echo $folder;
					if(is_file($folder)){
						echo "there is a file";

					}	
			          if(is_dir($folder)) {
			            $i++;
			            $FolderName=explode('/', $folder); $FolderName=end($FolderName);
			            // echo $FolderName;
			            echo "<option value='". $FolderName ."'>" .$FolderName ."</option>" ;
			            
			          }
			        }
		}


// if (isset($_GET['itemName'])) {
// 	if (isset($_GET['group'])) {
// 		if (isset($_GET['business'])) {
			
// 		}
	
// 	}
// }





 ?>