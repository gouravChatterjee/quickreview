<script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
</script>

<?php

$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);
if(mysqli_connect_error()){
	die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}

$session = $_GET['session'];
$session = preg_replace('/[^a-zA-Z0-9]/', '_', $session);

if(isset($_POST['submit'])){
	if(isset($_POST['date']))
		$date = $_POST['date'];


	$userId = $_SESSION['franId'];
	$notificationType = "Final Exam Question";
	$linkToGo = "uploadFinalQuestion";

	$sql = "INSERT INTO BS_NOTIFICATION (`USER_ID`, `STATUS`, `LINK`, `SUBJECT_DETAILS`, `SESSION`, `NOTIFICATION_DETAILS`)VALUES('$userId', 'PENDING', '$linkToGo', 'All_16_chapters', '$session', '$notificationType')";
	$result = mysqli_query($link, $sql);

	if(!$result){
          echo '<div class="alert alert-danger">There was a database error</div>';
          echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
         
    }else{
    	$type = "FINAL EXAM";
    	$sql = "INSERT INTO FRP_TB_EXAM_CONTROL (`FRANCHISE_ID`, `EXAM_TYPE`, `SESSION`, `SUBJECT`, `EXAM_DATE`)VALUES('$userId', '$type', '$session', 'All subject', '$date')";
    	$result = mysqli_query($link, $sql);
    	if ($result) {
    		$GLOBALS['alert_info'] .= DaddToBsAlert("Successfully registerd exam date");
    	}else{
    		  echo '<div class="alert alert-danger">There was a database error</div>';
          echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
           
        }
    	}


}


if ($GLOBALS['alert_info']!="") {
  echo $GLOBALS['alert_info'];
}




 ?>
<?php if ($_SESSION['LoggedIn']): ?>
 <div class="container">
 	<div class="col-sm-9 ml-auto mr-auto">
	<div class="tab-content" id="pills-tabContent">
		<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
            <div class="col-sm-12  border border-primary shadow rounded pt-2">


	 <h1 style="text-align: center;">Final Exam Question Paper</h1>
	 <h3 class="display-5" style="text-align: center;">Select your exam date atleast before 30 days</h3>
	 <hr>
	 	<br>
	 	
	 	<script>
		    if ( window.history.replaceState ) {
		        window.history.replaceState( null, null, window.location.href );
		    }
		</script>

	 		<!-- <div style="margin-left: 30%;"> -->
	 		<form method="POST" enctype="multipart/form-data" style=" margin-left:30%; margin-right:30%;">
 			<!-- <div class="form-group">
			  <label for="sel1">Program ID</label>



				<select name="programId" class="form-control" value="Select Program ID"> -->
					<!-- <?php

					// $sql1 = "SELECT DISTINCT(PROGRAM_ID) FROM FRP_TB_ANNEXURE_PROGRAM";

					// $result1 = mysqli_query($link,$sql1);
					// while ($row = mysqli_fetch_array($result1)){
					// echo "<option value='". $row['PROGRAM_ID'] ."'>" .$row['PROGRAM_ID'] ."</option>" ;
					// }
					?> -->
				<!-- </select>
			</div> -->

			<div class="form-group">
				<label for="sel1">Exam Date</label>
				<input type="text" id="datepicker" class="form-control" autocomplete="off" name="date" placeholder="click to select date" required>
				<br>
				<input type="submit" name="submit" value="Request Question Paper" class="btn btn-success btn-block">
			</div>









	 			</form>
	 			<hr>
	 			<p class="text-muted" style="text-align: center;"><span style="color: red;">**</span>Final Question paper download link will be available before 3 days of exam</p>


	 			<?php

	 			$userId = $_SESSION['franId'];
				$start_date = strtotime(date("Y-m-d"));


	 			$sql1 = "SELECT * FROM FRP_TB_EXAM_CONTROL WHERE FRANCHISE_ID = '$userId' AND EXAM_TYPE = 'FINAL EXAM'";

	 			$result1 = mysqli_query($link,$sql1);
	 			if(mysqli_num_rows($result1)>0){
				while ($row = mysqli_fetch_array($result1,MYSQLI_ASSOC)){
					$dateExam = $row['EXAM_DATE'];
					$session = $row['SESSION'];
					$end_date = strtotime($dateExam);
					$diff=($end_date - $start_date)/60/60/24;
					if($diff<=3 && $diff>=0){
						$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/FinalQuestion/".$session."/All_16_chapters/*");
						echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
					}

					// echo " ".$end_date;
					// echo " ".$start_date;
					}
				}



	 			 ?>
	 			 <br>





	 			<!-- </div> -->





	 			<br>

	 			<?php else: ?>
	 				<h1>You are not authorized</h1>
	 				<h4>Please Log in <a href="/sign">here</a></h4>


	 			  <?php endif; ?>






				<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
				<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

				<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/jquery-ui.js"></script>




<script>

  $(document).ready(function(){
	     $("#datepicker").datepicker({
	     	minDate:+30,
	     	maxDate: "+3M +10D",
	     	showAnim:"drop",
	     	dateFormat:"yy-mm-dd"
	     });

	     $("#bton").click(function(){
	     	$("#warning").show();
	     })
	});

</script>






</div>
</div>
</div>
</div>
</div>
<br>
<br>

