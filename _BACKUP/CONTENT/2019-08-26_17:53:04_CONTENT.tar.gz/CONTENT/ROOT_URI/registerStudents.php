<style type="text/css">
	.form-group.required .control-label:after { 
   content:"*";
   color:red;
}
</style>

<script type="text/javascript">
	$(document).ready(function(){
	$('input[type="checkbox"]').on('change', function() {
    $('input[name="' + this.name + '"]').not(this).prop('checked', false);
});
});
</script>


<?php 

	$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);
	if(mysqli_connect_error()){
		die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
	}

	$email = $_SESSION['user'];
	
	$sql = "SELECT * FROM BS_USER WHERE USER_EMAIL = '$email'";

   	$result = mysqli_query($link,$sql);
   	if ($result) {
   		if(mysqli_num_rows($result)>0){
   			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
   			$json = $row['USER_JSOND'];
   			$arr = json_decode($json, true);
   			foreach($arr as $key=>$value){
   				// echo $key."\n";
   				foreach ($value as $ke => $val) {
   					if ($ke == "Programs") {
   						$programs = explode(',',$val);
   						if (in_array("IIMTT", $programs))
						  {
						    $iimtt = true;
						    
						  }

						  if (in_array("YLE", $programs) || in_array("MAXBRAIN", $programs) || in_array("WRITO", $programs) || in_array("3P", $programs))
						  {
						    $non_iimtt = true;
						  }

   					}
   					
   					
   				}
			    
			}
   		}

   		 
   		
   	}

 ?>


<style type="text/css">
	.nav-pills .nav-link.active, .nav-pills .show>.nav-link {
		background-color: darkgreen;
	}
</style>






<?php if ($_SESSION['LoggedIn']): ?>

<div id="registermsg"></div>

<?php if ($iimtt && $non_iimtt): ?>



<div class="container">
    <div class="col-sm-9 ml-auto mr-auto">
        <ul class="nav nav-pills nav-fill mb-1" id="pills-tab" role="tablist" >
        	<li class="nav-item"> <a class="nav-link active" id="pills-iimtt-tab" data-toggle="pill" href="#pills-iimtt" role="tab" aria-controls="pills-iimtt" aria-selected="true">IIMTT Registration</a> </li>
            <li class="nav-item"> <a class="nav-link" id="pills-non-tab" data-toggle="pill" href="#pills-non" role="tab" aria-controls="pills-non" aria-selected="false">NON-IIMTT Registration</a>
         
        </ul>


        
       
 <div class="tab-content" id="pills-tabContent">
 	
    <div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
        <div class="col-sm-12 border border-primary shadow rounded pt-2">
         <form action="registerS" method="post" id="iimttregform">
         	
         	 <div class="row">
	        	<div class="col-sm-6">
	        		 <div class="form-group">
					    <label for="name">Name of Candidate <span style="color: red;">*</span></label>
					    <input type="text" class="form-control" id="nameofchild"  placeholder="Enter the name of Candidate" name="sName" required>

					  </div>
	            	
	      		</div>

	      		  <div class="col-sm-6">
	      		  	   <div class="form-group">
					    <label for="dateofbirth">Date of Birth <span style="color: red;">*</span></label>
					    <input type="date" class="form-control" id="dob" name="dob" required>

					  </div>

	      		  
	  		 	 </div>	            	
        </div>
	        

		  
        <div class="row">
        	<div class="col-sm-6">
        		 <div class="form-group">
				    <label for="number">Phone no. <span style="color: red;">*</span></label>
				    <input type="number" class="form-control" id="nameofchild"  placeholder="Enter the phn no." name="phn" required>

				  </div>
        	</div>
        	<div class="col-sm-6">
        		 <div class="form-group">
				    <label for="exampleInputEmail1">Email address <span style="color: red;">*</span></label>
				    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email" required>
				    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
				  </div>
        	</div>
        </div>

		 

		 <label for="program">Select your program <span style="color: red;">*</span></label>
				  <div class="form-check">
				    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="IIMTT Basic">
				    <label class="form-check-label" for="exampleCheck1">IIMTT Basic</label>
				  </div>
		      	  <div class="form-check">
				    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="IIMTT Advance">
				    <label class="form-check-label" for="exampleCheck1"> IIMTT Advance </label>
				  </div>
				  <br>

        <div class="row">
        	<div class="col">
        		 <div class="form-group">
				    <label for="exampleInputEmail1">Session <span style="color: red;">*</span></label>
				    <input type="text" class="form-control" id="dateenroll"  name="session" placeholder="Enter the Session">

				  </div>
        	</div>
        	<div class="col">
        		<div class="form-group">
				    <label for="exampleInputEmail1">Date of Enrollment <span style="color: red;">*</span></label>
				    <input type="date" class="form-control" id="dateenroll"  name="dateEnroll">

				 </div>
        	</div>
        	
        </div>
		  
		  

    

		  





		  <input type="submit" class="btn btn-primary btn-block" style="background-color: darkgreen;" value="Submit" name="submit">
                    </form>
                    <br>
                </div>
            </div>

         


            <div class="tab-pane fade" id="pills-non" role="tabpanel" aria-labelledby="pills-non-tab">
                <div class="col-sm-12 border border-primary shadow rounded pt-2">
             <form action="register_non" method="post" id="singnupFrom">
             <div class="row">
	        	<div class="col-sm-6">
	        		 <div class="form-group">
					    <label for="name">Name of Candidate <span style="color: red;">*</span></label>
					    <input type="text" class="form-control" id="nameofchild"  placeholder="Enter the name of Candidate" name="sName" required>

					  </div>
	            	
	      		</div>

	      		  <div class="col-sm-6">
	      		  	   <div class="form-group">
					    <label for="dateofbirth">Date of Birth <span style="color: red;">*</span></label>
					    <input type="date" class="form-control" id="dob" name="dob" required>

					  </div>

	      		  
	  		 	 </div>	            	
        </div>

        <div class="row">
        	<div class="col">
        		<div class="form-group">
				    <label for="name">Name of Father <span style="color: red;">*</span></label>
				    <input type="text" class="form-control" id="nameoffather"  placeholder="Enter the name of father" name="fathername" required>

				 </div>
        	</div>
        	<div class="col">
        		<div class="form-group">
				    <label for="name">Name of Mother<span style="color: red;">*</span></label>
				    <input type="text" class="form-control" id="nameoffather"  placeholder="Enter the name of mother" name="mothername" required>

				  </div>
        	</div>
        </div>

        <div class="row">
        	<div class="col">
        		 <div class="form-group">
				    <label for="number">Phone no of Parent<span style="color: red;">*</span></label>
				    <input type="number" class="form-control" id="nameofchild"  placeholder="Enter the phn no. of parent" name="phn" required>

				  </div>
        	</div>
        	<div class="col">
        		<div class="form-group">
				    <label for="exampleInputEmail1">Email address<span style="color: red;">*</span></label>
				    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email of Parent" name="email" required>
				    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
				  </div>
        	</div>
        </div>



		  
		   

		 

		  


		  <label for="program">Select your program<span style="color: red;">*</span></label>
		 
		   <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="YLE">
		    <label class="form-check-label" for="exampleCheck1">YLE</label>

		  </div>
		   <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="MAXBRAIN">
		    <label class="form-check-label" for="exampleCheck1">MAXBRAIN</label>

		  </div>
		   <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="WRITO">
		    <label class="form-check-label" for="exampleCheck1">WRITO</label>

		  </div>
		   <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="3P">
		    <label class="form-check-label" for="exampleCheck1">3P</label>

		  </div>

		  <div class="row">
		  	<div class="col">
		  		<div class="form-group">
				    <label for="exampleInputEmail1">Session <span style="color: red;">*</span></label>
				    <input type="text" class="form-control" id="dateenroll"  name="session" placeholder="Enter the Session">

				  </div>
		  	</div>
		  	<div class="col">
		  		<div class="form-group">
				    <label for="exampleInputEmail1">Date of Enrollment<span style="color: red;">*</span></label>
				    <input type="date" class="form-control" id="dateenroll"  name="dateEnroll" required>

				  </div>
		  	</div>
		  </div>

		  





		  <button type="submit" class="btn btn-primary btn-block" style="background-color: darkgreen;" name="submit">Submit</button>
                    </form>
                    <br>
                </div>
            </div>
        </div>
    </div>
</div>













<?php elseif ($iimtt): ?>

<div class="container">
    <div class="col-sm-9 ml-auto mr-auto">
        <ul class="nav nav-pills nav-fill mb-1" id="pills-tab" role="tablist">
        	
            <li class="nav-item"> <a class="nav-link active" id="pills-iimtt-tab" data-toggle="pill" href="#pills-iimtt" role="tab" aria-controls="pills-iimtt" aria-selected="true">IIMTT Registration</a> </li>
            
         
        </ul>



       
         <div class="tab-content" id="pills-tabContent">
         	
            <div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
                <div class="col-sm-12 border border-primary shadow rounded pt-2">
                    <!-- <div class="text-center"><img src="https://placehold.it/80x80" class="rounded-circle border p-1"></div> -->
         <form action="registerS" method="post" id="iimttregform">


          <div class="row">
	        	<div class="col-sm-6">
	        		 <div class="form-group">
					    <label for="name">Name of Candidate <span style="color: red;">*</span></label>
					    <input type="text" class="form-control" id="nameofchild"  placeholder="Enter the name of Candidate" name="sName" required>

					  </div>
	            	
	      		</div>

	      		  <div class="col-sm-6">
	      		  	   <div class="form-group">
					    <label for="dateofbirth">Date of Birth <span style="color: red;">*</span></label>
					    <input type="date" class="form-control" id="dob" name="dob" required>

					  </div>

	      		  
	  		 	 </div>	            	
        </div>
	        

		  
        <div class="row">
        	<div class="col-sm-6">
        		 <div class="form-group">
				    <label for="number">Phone no. <span style="color: red;">*</span></label>
				    <input type="number" class="form-control" id="nameofchild"  placeholder="Enter the phn no." name="phn" required>

				  </div>
        	</div>
        	<div class="col-sm-6">
        		 <div class="form-group">
				    <label for="exampleInputEmail1">Email address <span style="color: red;">*</span></label>
				    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email" required>
				    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
				  </div>
        	</div>
        </div>

		 

		 <label for="program">Select your program <span style="color: red;">*</span></label>
				  <div class="form-check">
				    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="IIMTT Basic">
				    <label class="form-check-label" for="exampleCheck1">IIMTT Basic</label>
				  </div>
		      	  <div class="form-check">
				    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="IIMTT Advance">
				    <label class="form-check-label" for="exampleCheck1"> IIMTT Advance </label>
				  </div>
				  <br>

        <div class="row">
        	<div class="col">
        		 <div class="form-group">
				    <label for="exampleInputEmail1">Session <span style="color: red;">*</span></label>
				    <input type="text" class="form-control" id="dateenroll"  name="session" placeholder="Enter the Session">

				  </div>
        	</div>
        	<div class="col">
        		<div class="form-group">
				    <label for="exampleInputEmail1">Date of Enrollment <span style="color: red;">*</span></label>
				    <input type="date" class="form-control" id="dateenroll"  name="dateEnroll">

				 </div>
        	</div>
        	
        </div>
		  
		  

    

		  





		  <input type="submit" class="btn btn-primary btn-block" style="background-color: darkgreen;" value="Submit" name="submit">
                    </form>
                    <br>
                </div>
            </div>

         



        </div>
    </div>
</div>

<?php else: ?>
	<div class="container">
    <div class="col-sm-9 ml-auto mr-auto">
        <ul class="nav nav-pills nav-fill mb-1" id="pills-tab" role="tablist">
        	
            
            <li class="nav-item"> <a class="nav-link active" id="pills-non-tab" data-toggle="pill" href="#pills-non" role="tab" aria-controls="pills-non" aria-selected="true">Student Registration</a>
         
        </ul>



       
         <div class="tab-content" id="pills-tabContent">
         	
           

         


            <div class="tab-pane fade show active" id="pills-non" role="tabpanel" aria-labelledby="pills-non-tab">
                <div class="col-sm-12 border border-primary shadow rounded pt-2">
                    <!-- <div class="text-center"><img src="https://placehold.it/80x80" class="rounded-circle border p-1"></div> -->
             <form action="register_non" method="post" id="singnupFrom">
                        <div class="row">
	        	<div class="col-sm-6">
	        		 <div class="form-group">
					    <label for="name">Name of Candidate <span style="color: red;">*</span></label>
					    <input type="text" class="form-control" id="nameofchild"  placeholder="Enter the name of Candidate" name="sName" required>

					  </div>
	            	
	      		</div>

	      		  <div class="col-sm-6">
	      		  	   <div class="form-group">
					    <label for="dateofbirth">Date of Birth <span style="color: red;">*</span></label>
					    <input type="date" class="form-control" id="dob" name="dob" required>

					  </div>

	      		  
	  		 	 </div>	            	
        </div>

        <div class="row">
        	<div class="col">
        		<div class="form-group">
				    <label for="name">Name of Father <span style="color: red;">*</span></label>
				    <input type="text" class="form-control" id="nameoffather"  placeholder="Enter the name of father" name="fathername" required>

				 </div>
        	</div>
        	<div class="col">
        		<div class="form-group">
				    <label for="name">Name of Mother<span style="color: red;">*</span></label>
				    <input type="text" class="form-control" id="nameoffather"  placeholder="Enter the name of mother" name="mothername" required>

				  </div>
        	</div>
        </div>

        <div class="row">
        	<div class="col">
        		 <div class="form-group">
				    <label for="number">Phone no of Parent<span style="color: red;">*</span></label>
				    <input type="number" class="form-control" id="nameofchild"  placeholder="Enter the phn no. of parent" name="phn" required>

				  </div>
        	</div>
        	<div class="col">
        		<div class="form-group">
				    <label for="exampleInputEmail1">Email address<span style="color: red;">*</span></label>
				    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email of Parent" name="email" required>
				    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
				  </div>
        	</div>
        </div>



		  
		   

		 

		  


		  <label for="program">Select your program<span style="color: red;">*</span></label>
		 
		   <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="YLE">
		    <label class="form-check-label" for="exampleCheck1">YLE</label>

		  </div>
		   <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="MAXBRAIN">
		    <label class="form-check-label" for="exampleCheck1">MAXBRAIN</label>

		  </div>
		   <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="WRITO">
		    <label class="form-check-label" for="exampleCheck1">WRITO</label>

		  </div>
		   <div class="form-check">


		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]" value="3P">
		    <label class="form-check-label" for="exampleCheck1">3P</label>

		  </div>

		  <div class="row">
		  	<div class="col">
		  		<div class="form-group">
				    <label for="exampleInputEmail1">Session <span style="color: red;">*</span></label>
				    <input type="text" class="form-control" id="dateenroll"  name="session" placeholder="Enter the Session">

				  </div>
		  	</div>
		  	<div class="col">
		  		<div class="form-group">
				    <label for="exampleInputEmail1">Date of Enrollment<span style="color: red;">*</span></label>
				    <input type="date" class="form-control" id="dateenroll"  name="dateEnroll" required>

				  </div>
		  	</div>
		  </div>

		  





		  <button type="submit" class="btn btn-primary btn-block" style="background-color: darkgreen;" name="submit">Submit</button>
                    </form>
                    <br>
                </div>
            </div>
        </div>
    </div>
</div>









 	<?php endif; ?>

<?php else: ?>
	<h1>You are not authorized</h1>
	<h4>Please Log in <a href="/sign">here</a></h4>

<?php endif; ?>
