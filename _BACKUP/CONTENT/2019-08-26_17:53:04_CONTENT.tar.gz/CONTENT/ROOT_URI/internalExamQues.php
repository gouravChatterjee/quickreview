<script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
</script>



<?php 
$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);

if(mysqli_connect_error()){
	die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}

$session = $_GET['session'];
$session = preg_replace('/[^a-zA-Z0-9]/', '_', $session);


function checkFile($value){
	$franId = $_SESSION['franId'];
	$session = $_GET['session'];
	$session = preg_replace('/[^a-zA-Z0-9]/', '_', $session);


	$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/".$value."/*");
	if (count($files) > 0)
		return true;
	// if(file_exists("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$value."/Recieved.txt"))
	// 	return true;
}

function isPending($value){
	$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);

	$franId = $_SESSION['franId'];
	$sql = "SELECT * FROM BS_NOTIFICATION WHERE USER_ID = '$franId' AND SUBJECT_DETAILS = '$value' AND STATUS = 'PENDING'";
	$result = mysqli_query($link, $sql);
	if ($result) {
		 if(mysqli_num_rows($result)>0){
		 	return true;
		 }
	}else{
		echo '<div class="alert alert-danger">There was a database error</div>';
        echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
	}
}
	


 ?>


<?php if ($_SESSION['LoggedIn']): ?>

<?php if ($_GET['session']): ?>



<div class="container">
 	<div class="col-sm-10 ml-auto mr-auto">
		<div class="tab-content" id="pills-tabContent">
			<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
	            <div class="col-sm-12  border border-primary shadow rounded pt-2">
	            	<h1 style="text-align: center;">Internal Exam Question</h1>
	            	<hr>
	            	<h5><i class="fas fa-angle-double-right"></i> Montessori Diploma, Advanced Montessori Diploma</h5>
	            	<hr>
	            	<div class="table-responsive">
		            	<table class="table table-bordered table-hover" id="taa">
						  <thead class="thead-dark">
						    <tr>
						      <th scope="col">Serial</th>
						      <th scope="col">Subject</th>
						      <th scope="col">Subject Code</th>
						      <th scope="col">Question</th>
						     
						    </tr>
						   </thead>
						    
						     	
						     
						      <tbody>
						      	<tr>
						      		<td scope="col">1</td>
						      		<td scope="col">Chapter 1</td>
						      		<td scope="col">DM101</td>
						      		<?php 
						      		// $session = $_GET['session'];
						      		if(checkFile("DM101")){
						      			$franId = $_SESSION['franId'];
						      			
						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DM101/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}elseif (isPending("DM101")) {
						    			echo '<td><a href="" class="btn btn-warning" name="1"><i class="fa fa-clock" aria-hidden="true"></i> Pending</a></td>';
						    		} else{
						      			
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DM101&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


						    		


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">2</td>
						      		<td scope="col">Chapter 2</td>
						      		<td scope="col">DM102</td>
						      		<?php 
						      		// $session = $_GET['session'];
						      		if(checkFile("DM102")){
						    			$franId = $_SESSION['franId'];
						    			

						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DM102/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DM102")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}  
						    		else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DM102&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">3</td>
						      		<td scope="col">Chapter 3</td>
						      		<td scope="col">DM103</td>
						      		<?php 
						      		// $session = $_GET['session'];
						      		if(checkFile("DM103")){
						    			$franId = $_SESSION['franId'];
						    			// $session = $_POST['session'];

						    			// echo $session;
						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DM103/*");

						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DM103")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DM103&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">4</td>
						      		<td scope="col">Chapter 4</td>
						      		<td scope="col">DM104</td>
						      		<?php 
						      		// $session = $_GET['session'];
						      		if(checkFile("DM104")){
						    			$franId = $_SESSION['franId'];
						    			

						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DM104/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DM104")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DM104&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">5</td>
						      		<td scope="col">Chapter 5</td>
						      		<td scope="col">DM105</td>
						      		<?php 
						      		// $session = $_GET['session'];
						      		if(checkFile("DM105")){
						    			$franId = $_SESSION['franId'];
						    			

						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DM105/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DM105")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DM105&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">6</td>
						      		<td scope="col">Chapter 6</td>
						      		<td scope="col">DM106</td>
						      		<?php 
						      		// $session = $_GET['session'];
						      		if(checkFile("DM106")){
						    			$franId = $_SESSION['franId'];
						    			

						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DM106/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DM106")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DM106&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">7</td>
						      		<td scope="col">Chapter 7</td>
						      		<td scope="col">DM107</td>
						      		<?php
						      		$session = $_GET['session']; 
						      		if(checkFile("DM107")){
						    			$franId = $_SESSION['franId'];
						    			

						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DM107/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DM107")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DM107&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">8</td>
						      		<td scope="col">Chapter 8</td>
						      		<td scope="col">DM108</td>
						      		<?php 
						      		// $session = $_GET['session'];
						      		if(checkFile("DM108")){
						    			$franId = $_SESSION['franId'];
						    			

						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DM108/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DM108")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DM108&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      </tbody>
						  </table>
						</div>
						  <hr>
						  <h5><i class="fas fa-angle-double-right"></i>Advanced Montessori Diploma</h5>
						  <hr>
						  <div class="table-responsive">
		            	<table class="table table-bordered table-hover" id="taa">
						  <thead class="thead-dark">
						    <tr>
						      <th scope="col">Serial</th>
						      <th scope="col">Subject</th>
						      <th scope="col">Subject Code</th>
						      <th scope="col">Question</th>
						     
						    </tr>
						   </thead>
						    
						     	
						     
						      <tbody>
						      	<tr>
						      		<td scope="col">9</td>
						      		<td scope="col">Chapter 9</td>
						      		<td scope="col">DA101</td>
						      		<?php 
						      		// $session = $_GET['session'];
						      		if(checkFile("DA101")){
						    			$franId = $_SESSION['franId'];
						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DA101/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DA101")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DA101&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">10</td>
						      		<td scope="col">Chapter 10</td>
						      		<td scope="col">DA102</td>
						      		<?php 
						      		// $session = $_GET['session'];
						      		if(checkFile("DA102")){
						    		$franId = $_SESSION['franId'];
						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DA102/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DA102")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DA102&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">11</td>
						      		<td scope="col">Chapter 11</td>
						      		<td scope="col">DA103</td>
						      		<?php 
						      		if(checkFile("DA103")){
						    			$franId = $_SESSION['franId'];
						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DA103/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DA103")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}  else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DA103&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">12</td>
						      		<td scope="col">Chapter 12</td>
						      		<td scope="col">DA104</td>
						      		<?php 
						      		if(checkFile("DA104")){
						    			$franId = $_SESSION['franId'];
						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DA104/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DA104")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DA104&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">13</td>
						      		<td scope="col">Chapter 13</td>
						      		<td scope="col">DA105</td>
						      		<?php 
						      		if(checkFile("DA105")){
						    			$franId = $_SESSION['franId'];
						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DA105/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DA105")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DA105&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">14</td>
						      		<td scope="col">Chapter 14</td>
						      		<td scope="col">DA106</td>
						      		<?php 
						      		if(checkFile("DA106")){
						    			$franId = $_SESSION['franId'];
						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DA106/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DA106")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DA106&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">15</td>
						      		<td scope="col">Chapter 15</td>
						      		<td scope="col">DA107</td>
						      		<?php 
						      		if(checkFile("DA107")){
						    			$franId = $_SESSION['franId'];
						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DA107/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DA107")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DA107&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      	<tr>
						      		<td scope="col">16</td>
						      		<td scope="col">Chapter 16</td>
						      		<td scope="col">DA108</td>
						      		<?php 
						      		if(checkFile("DA108")){
						    			$franId = $_SESSION['franId'];
						      			$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$session."/"."DA108/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}
						    		elseif(isPending("DA108")) {
						    			echo '<td><a href="#" class="btn btn-warning" name="1"><i class="fa fa-clock"></i> Pending</a></td>';
						    		}   else{
						    			echo '<td><a href="requestQues?session='.$session.'&subject=DA108&franId='.$_SESSION['franId'].'" class="btn btn-danger" name="1"><i class="fa fa-upload"></i> Request</a></td>';
						    		}


							      ?>
						      	</tr>
						      </tbody>
						  </table>
						</div>


						</div>

	            </div>
	        </div>
        </div>
    </div>
</div>

	<?php else: ?>
		<h1>Please select the session first</h1>
		<h4>Please go to <a href="/ExamControl">here</a></h4>
	<?php endif; ?>

<?php else: ?>
	<h1>You are not authorized</h1>
	<h4>Please Log in <a href="/sign">here</a></h4>


<?php endif; ?>