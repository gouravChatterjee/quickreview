    <link rel="stylesheet" href="/CSS/video.css" >

<body>
<div class="page-wrapper chiller-theme toggled">
  <a id="show-sidebar" class="btn btn-sm btn-dark" href="#">
    <i class="fas fa-bars"></i>
  </a>
  <nav id="sidebar" class="sidebar-wrapper">
    <div class="sidebar-content">
      <div class="sidebar-brand">
        <h2 style="color: #ffffff;">IIMTT      </h2>
        <div id="close-sidebar" style="margin-left: 100px;">
          <i class="fas fa-times"></i>
        </div>
      </div>
      <div class="sidebar-header">
        
        <div class="user-info">
         <h3>Franchise Induction</h3>
        </div>
      </div>
      <!-- sidebar-header  -->
      <div class="sidebar-search">
        
      </div>
      <!-- sidebar-search  -->
      <div class="sidebar-menu">
        <ul>
          <li class="header-menu">
            <div>
               <span style="color: #ffffff;">Lessons</span>
            </div>
          </li>
          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-circle"></i>
              <span>How to use this portal?</span>
              
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>
                  <a href="#" onclick="showText('/How_to_use_this_portal/How_to_use.txt','How to use this Potal?');">how to use this portal?</a>
                </li>
                <!-- https://cdn.preschool-curriculum.in/BeansTalk/videos/How_to_use_this_portal/How_to_use.txt -->

                <!-- https://rolebased.sgp1.digitaloceanspaces.com/BeansTalk/videos/How_to_use_this_portal/How_to_use.txt -->
                <!-- https://rolebased.sgp1.digitaloceanspaces.com/BeansTalk/videos/About_IIMTT/Background.txt -->
               
              </ul>
            </div>
          </li>
          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-circle"></i>
              <span>About IIMTT</span>
              
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>
                  <a href="#" onclick="showText('/About_IIMTT/Background.txt','Background');">Backgrounds

                  </a>
                </li>
                <li>
                  <a href="#" onclick="showText('/About_IIMTT/our%20USPs.txt','Our USPs');">Our USPs</a>
                  
                </li>
                <li>
                  <a href="#" onclick="showText('/About_IIMTT/Recommended%20Batches%20with%20our%20product.txt','Recommended Batches');">Recommended Batches with our product</a>

                </li>
                <li>
                  <!-- https://cdn.preschool-curriculum.in/BeansTalk/videos/About_IIMTT/IIMTT%20explainer%20Video.mp4 -->
                  <a href="#" onclick="playVideo('/About_IIMTT/IIMTT%20explainer%20Video.mp4','IIMTT Explainer Video');">IIMTT Explainer Video</a>
                </li>
              </ul>
            </div>
          </li>
          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-circle"></i>
              <span>Onboarding</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>
                  <a href="#" onclick="playVideo('/Onboarding/onboardingvideo.mp4','Onboarding Video');">Onboarding Video</a>
                  
                </li>
                <li>

                  <a href="#" onclick="showPdf('/Onboarding/HandoverChecklist-1559940232586.pdf','Handover Checklist');">Handover Checklist(For franchisees to crosscheck and confirm)</a>
                </li>
                
              </ul>
            </div>
          </li>
          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-circle"></i>
              <span>Lesson Plan</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>

                  <a href="#" onclick="showPdf('/Lesson_plan/Basic_course-regular_batch.pdf','Basic Course - Regular Batch');">Basic Course - Regular Batch</a>
                </li>
                <li>
                  <a href="#" onclick="showPdf('/Lesson_plan/BasicCourseHighLevelLessonPlanWeekend-1559943496575.pdf','Basic Course - Weekend Batch');">Basic Course - Weekend Batch</a>

                </li>
                
              </ul>
            </div>
          </li>
          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-circle"></i>
              <span>Albums & Practice Teaching Videos</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>
                  <a href="#" onclick="showWmv('/Albums_and_practice_teaching_videos/albums.wmv','Albums Video');">Albums</a>
                 <!--  https://cdn.preschool-curriculum.in/BeansTalk/videos/Albums_and_practice_teaching_videos/albums.wmv -->
               

                </li>
                <li>
                  <a href="#" onclick="showWmv('/Albums_and_practice_teaching_videos/practiceTeaching.wmv','Practice Teaching Video');">Practice Teaching</a>
                </li>
                <li>
                  <a href="#" onclick="playVideo('/Albums_and_practice_teaching_videos/practiceTeaching-GroupActivity.mp4','Practice Teaching- Group Activity');">Practice Teaching- Group Activity</a>
                </li>
                <li>
                
                  <a href="#" onclick="playVideo('/Albums_and_practice_teaching_videos/practiceTeaching-studentInteraction.mp4','Practice Teaching- Interaction Session with kids');">Practice Teaching- Interaction Session with kids</a>
                </li>
                <li>
                  <!-- https://cdn.preschool-curriculum.in/BeansTalk/videos/Albums_and_practice_teaching_videos/practiceTeaching-storyTell.mp4 -->
                  <a href="#" onclick="playVideo('/Albums_and_practice_teaching_videos/practiceTeaching-storyTell.mp4','Practice Teaching- Story Telling');">Practice Teaching- Story Telling</a>
                </li>
                <li>

                  <a href="#" onclick="showWmv('/Albums_and_practice_teaching_videos/AlbumsPracticeTeachingVideos20190611T195445Z001-1560284766068.zip','Albums & Practice Teaching Videos');">Albums & Practice Teaching Videos(Download)</a>
                </li>
              </ul>
            </div>
          </li>

          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-circle"></i>
              <span>Theory Supporting Videos</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>

                  <a href="#" onclick="showWmv('/Theory_supporting_videos/TheorySupportingVideos-1559950802182.zip','All Supporting Videos');">All Supporting Videos(Download)</a>
                </li>
                
                
              </ul>
            </div>
          </li>

           <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-circle"></i>
              <span>Practical presentation Videos</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>

                  <a href="#" onclick="showWmv('/practical_presentation_videos/practical%20presentation.zip','Practical Presentations');">Practical Presentations(Download)</a>
                </li>
                
                
              </ul>
            </div>
          </li>
          
          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-circle"></i>
              <span>Augmented Curriculum Videos</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>

                  <a href="#" onclick="showWmv('/Augmented_Curriculam_Videos/Bias-Gender_Stereotyping.wmv','Bias - Gender Stereotyping');">Bias - Gender Stereotyping</a>
                </li>
                <li>
                  <!-- https://cdn.preschool-curriculum.in/BeansTalk/videos/Augmented_Curriculam_Videos/Curriculam.wmv -->
                  <a href="#" onclick="showWmv('/Augmented_Curriculam_Videos/Curriculam.wmv','Curriculum');">Curriculum</a>
                </li>
                 <li>

                  <a href="#" onclick="showWmv('/Augmented_Curriculam_Videos/Deductive_vs_Inductive_Learning.wmv','Deductive vs Inductive Learning');">Deductive vs Inductive Learning</a>
                </li>
                <li>
                  
                  <a href="#" onclick="showWmv('/Augmented_Curriculam_Videos/Lev_Vygotsky.wmv','Lev Vygotsky');">Lev Vygotsky</a>
                </li>
                <li>
                  
                  <a href="#" onclick="showWmv('/Augmented_Curriculam_Videos/Nature_and_Nurture.wmv','Nature and Nurture');">Nature and Nurture</a>
                </li>
                <li>
                  
                  <a href="#" onclick="showWmv('/Augmented_Curriculam_Videos/observation_tasks.wmv','Observation Tasks');">Observation Tasks</a>
                </li>
                <li>
                  <a href="#" onclick="showWmv('/Augmented_Curriculam_Videos/Piagets_theory.wmv','Piagets Theory');">Piagets Theory</a>
                </li>
                <li>

                  <a href="#" onclick="showWmv('/Augmented_Curriculam_Videos/Prenatal_Postnatal_Development.wmv','Prenatal_Postnatal Development');">Prenatal_Postnatal Development</a>
                </li>
                <li>

                  <a href="#" onclick="showWmv('/Augmented_Curriculam_Videos/Separation_anxiety.wmv','Separation Anxiety');">Separation Anxiety</a>
                </li>
                <li>

                  <a href="#" onclick="showWmv('/Augmented_Curriculam_Videos/Techniques_of_teaching.wmv','Techniques of Teaching');">Techniques of Teaching</a>
                </li>            
              </ul>
            </div>
          </li>

          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-circle"></i>
              <span>Practical Supporting Videos</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>
                  <a href="#">Exercise of Practical Life(EPL)</a>
                </li>
                <li>
                  <a href="#">Language</a>
                </li>
                <li>
                  <a href="#">Sensorial</a>
                </li>
                <li>
                  <a href="#">Math</a>
                </li>
              </ul>
            </div>
          </li>

                 <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-circle"></i>
              <span>Marketing Collaterals</span>
            </a>
            <div class="sidebar-submenu">

              <ul>
                <li>
                  <a href="#" onclick="showWmv('/Marketing_Colaterrals/Collaterals.zip','Collaterals');">Collaterals(Download)</a>
                </li>
                <li>
                  <a href="#" onclick="showWmv('/Marketing_Colaterrals/Base_files_and_other_customizable_materials.zip','Base Files and Other Customizable Promotional Materials');">Base Files and Other Customizable Promotional Materials(Download)</a>
                </li>
             </ul>
            </div>
          </li>
          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-circle"></i>
              <span>Miscellaneous Documents</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>
                  
                  <a href="#" onclick="showWmv('/Miscellaneous_Documents/Miscellaneous_Documents.zip','Sample certificate, marksheet, program of work & miscellaneous presentations(Download)');">Sample certificate, marksheet, program of work & miscellaneous presentations(Download)</a>
                </li>
             </ul>
            </div>
          </li>

           <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-circle"></i>
              <span>Feedback</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>
                  <a href="#">Feedback Form</a>
                </li>
             </ul>
            </div>
          </li>
          
         
      </div>
      <!-- sidebar-menu  -->
    </div>
    <!-- sidebar-content  -->
    
  </nav>
  <!-- sidebar-wrapper  -->
  <main class="page-content">
    <div class="container-fluid">

      <h2 id="title"></h2>
       <center>
      <div id="show">
       <h2>How To Use This Portal?</h2>
       <p>This online training will take not more than a couple of hours to complete. There is a vast repository available after the first two chapters (About IIMTT and Onboarding). This repository should be downloaded and used as per terms of engagement in your agreement with IIMTT. Circulation is strictly prohibited. <br><br>

        Go through the repository in detail before your in-person or online interaction cum training with us. It will help to orient yourselves to the programs better and help shape a better understanding during the training process. Happy learning!</p>
      <!-- <iframe src="https://cdn.preschool-curriculum.in/BeansTalk/videos/How_to_use_this_portal/How_to_use.txt" width="100%" height="400" frameborder="0">; -->
        
        
      </div>
    </center>

      
    </div>

  </main>
  <!-- page-content" -->
</div>
<!-- page-wrapper -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
    
</body>
<script src="JS/video.js"></script>
<script src="JS/showVideos.js"></script>

</html>