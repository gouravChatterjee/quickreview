

<?php if ($_SESSION['LoggedIn']): ?>


<div class="container">
 	<div class="col-sm-8 ml-auto mr-auto">
	<div class="tab-content" id="pills-tabContent">
		<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
            <div class="col-sm-12  border border-primary shadow rounded pt-2">
            	<h2 style="text-align: center;">Exam Control System</h2>
            	<hr>
                <div class="row" style="margin-left: 1.5%;">
                    <div class="col-md">
                        <div class="card" style="width: 18rem;">
                          <div class="card-body" style="text-align: center;">
                            <i class="fas fa-book" style="font-size: 100px;" ></i>
                            <h5 class="card-title">Internal Exam</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <a href="selectSession?type=internal" class="btn btn-primary">Request Question</a>
                          </div>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="card" style="width: 18rem;">
                         
                          <div class="card-body" style="text-align: center;">
                            <i class="fas fa-graduation-cap" style="font-size: 100px;" ></i>
                            <h5 class="card-title">Final Exam</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            <a href="selectSession?type=final" class="btn btn-primary">Request Question</a>
                          </div>
                        </div>
                    </div>
                    
                </div>
                <br>

            </div>
            <br>
        </div>
    </div>
    <br>
	</div>
</div>








<?php else: ?>
	<h1>You are not authorized</h1>
	<h4>Please Log in <a href="/sign">here</a></h4>


<?php endif; ?>