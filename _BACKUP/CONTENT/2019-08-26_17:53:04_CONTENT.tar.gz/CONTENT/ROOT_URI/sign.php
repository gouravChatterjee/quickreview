<script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
  </script>



<?php if ($_SESSION['LoggedIn']): ?>
    echo "<script>
            window.location.href='profile';
            </script>";


<?php endif; ?>





<?php if (!$_SESSION['LoggedIn']): ?>



<div class="container mt-2 mb-4">
    <div class="col-sm-8 ml-auto mr-auto">
        <!-- <ul class="nav nav-pills nav-fill mb-1" id="pills-tab" role="tablist">
            <li class="nav-item"> <a class="nav-link active" id="pills-signin-tab" data-toggle="pill" href="#pills-signin" role="tab" aria-controls="pills-signin" aria-selected="true">Sign In</a> </li>
            <li class="nav-item"> <a class="nav-link" id="pills-signup-tab" data-toggle="pill" href="#pills-signup" role="tab" aria-controls="pills-signup" aria-selected="false">Sign Up</a> </li>
        </ul> -->
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-signin" role="tabpanel" aria-labelledby="pills-signin-tab">
                <div class="col-sm-12 border border-primary shadow rounded pt-2">
                    <!-- <div class="text-center"><img src="https://placehold.it/80x80" class="rounded-circle border p-1"></div> -->
                    <form method="post" id="singninFrom" enctype=“multipart/form-data”> <input type="hidden" name="s_Hash" value="<?php echo $_SESSION['s_Hash']; ?>">
                        <input type="hidden" name="formName" value="singninFrom">
                        <div class="form-group">
                            <label class="font-weight-bold">Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" id="email_signin" class="form-control" placeholder="Enter valid email" required>
                        </div>
                        <div class="form-group">
                            <label class="font-weight-bold">Password <span class="text-danger">*</span></label>
                            <input type="password" name="password" id="password" class="form-control" placeholder="***********" required>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col">
                                    <label><input type="checkbox" name="condition" id="condition"> Remember me.</label>
                                </div>
                                <div class="col text-right"> <a href="javascript:;" data-toggle="modal" data-target="#forgotPass">Forgot Password?</a> </div>
                            </div>
                        </div>
                        <div class="form-group" style="margin-bottom:10px;">
                            <input type="submit" name="submit" value="Sign In" class="btn btn-block btn-primary">
                        </div>
                    </form>
                </div>
            </div>
            <!-- <div class="tab-pane fade" id="pills-signup" role="tabpanel" aria-labelledby="pills-signup-tab">
                <div class="col-sm-12 border border-primary shadow rounded pt-2"> -->
                    <!-- <div class="text-center"><img src="https://placehold.it/80x80" class="rounded-circle border p-1"></div> -->
                    <!-- <form method="post" id="singnupFrom"> <input type="hidden" name="s_Hash" value="<?php ?>">
                        <input type="hidden" name="formName" value="singnupFrom">
                        <div class="form-group">
                            <label class="font-weight-bold">Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" id="email_signup" class="form-control" placeholder="Enter valid email" required>
                        </div> -->
                        <!-- <div class="form-group">
                            <label class="font-weight-bold">User Name <span class="text-danger">*</span></label>
                            <input type="text" name="username" id="username" class="form-control" placeholder="Choose your user name" required>
                            <div class="text-danger"><em>This will be your login name!</em></div>
                        </div> -->
                        <!-- <div class="form-group">
                            <label class="font-weight-bold">Phone #</label>
                            <input type="text" name="phone" id="phone" class="form-control" placeholder="(0000000000)" required>
                        </div>
                        <div class="form-group">
                            <label class="font-weight-bold">Password <span class="text-danger">*</span></label>
                            <input type="password" name="password_1" id="password_1" class="form-control" placeholder="***********" pattern="^\S{6,}$" onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Must have at least 6 characters' : ''); if(this.checkValidity()) form.password_two.pattern = this.value;" required>
                        </div>
                        <div class="form-group">
                            <label class="font-weight-bold">Confirm Password <span class="text-danger">*</span></label>
                            <input type="password" name="password_2" id="password_2" class="form-control" pattern="^\S{6,}$" onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Please enter the same Password as above' : '');" placeholder="***********" required>
                        </div>
                        <div class="form-group">
                            <label><input type="checkbox" name="signupcondition" id="signupcondition" required> I agree with the <a href="javascript:;">Terms &amp; Conditions</a> for Registration.</label>
                        </div>
                        <div class="form-group" style="margin-bottom:10px;">
                            <input type="submit" name="signupsubmit" value="Sign Up" class="btn btn-block btn-primary">
                        </div>


                    </form>
                </div>
            </div> -->





        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="forgotPass" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form method="post" id="forgotpassForm">
                <input type="hidden" name="s_Hash" value="<?php echo $_SESSION['s_Hash']; ?>">
                <input type="hidden" name="FORM_NAME" value="forgotPasswordForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Forgot Password</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Email <span class="text-danger">*</span></label>
                            <input type="email" name="forgotemail" id="forgotemail" class="form-control" placeholder="Enter your valid email..." required>
                        </div>
                        <div class="form-group">
                        </div>
                    </div>
                    <div class="modal-footer">
                      
                        <button type="submit" name="sendMail" class="btn btn-primary"><i class="fa fa-envelope"></i> Send Request</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

</div>


<?php endif; ?>


<?php
if ($GLOBALS['alert_info']!="") {
  echo $GLOBALS['alert_info'];
}
?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

