<?php 
	$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);

	if(mysqli_connect_error()){
		die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
	}
	$quesId = $_GET['subject'];
	$userId = $_GET['franId'];
  $session = $_GET['session'];

	$linkToGo = 'UploadQuestionPaper';
	$notificationType = "Internal Exam Question";
	
	$sql = "INSERT INTO BS_NOTIFICATION (`USER_ID`, `STATUS`, `LINK`, `SUBJECT_DETAILS`, `SESSION`, `NOTIFICATION_DETAILS`)VALUES('$userId', 'PENDING', '$linkToGo', '$quesId', '$session', '$notificationType')";

	$result = mysqli_query($link, $sql);

	if(!$result){
          echo '<div class="alert alert-danger">There was a database error</div>';
          echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
         
    }else{
    	$type = "INTERNAL EXAM";
    	$sql = "INSERT INTO FRP_TB_EXAM_CONTROL (`FRANCHISE_ID`, `EXAM_TYPE`, `SESSION`, `SUBJECT`)VALUES('$userId', '$type', '$session', '$quesId')";
    	$result = mysqli_query($link, $sql);
    	if ($result) {
    		echo "
                <script>
                
                 window.location.href='internalExamQues?session=".$session."';
                </script>
                ";
    	}else{
    		  echo '<div class="alert alert-danger">There was a database error</div>';
          echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
           
        }
    	}
	






 ?>