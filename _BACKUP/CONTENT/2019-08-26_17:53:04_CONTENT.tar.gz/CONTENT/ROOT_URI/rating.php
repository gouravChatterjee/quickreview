
<style type="text/css">
	.star{
		cursor: pointer;
		font-size: 100px;

	}
	.star.yel{
		color: #00cc00;
	}
	
</style>




<div class="container">
	<i class="fas fa-star star"></i>
	<i class="fas fa-star star"></i>
	<i class="fas fa-star star"></i>
	<i class="fas fa-star star"></i>
	<i class="fas fa-star star"></i>
</div>
<script type="text/javascript">
	$(".star").click(function () {
   $(this).toggleClass("yel");
});

</script>


