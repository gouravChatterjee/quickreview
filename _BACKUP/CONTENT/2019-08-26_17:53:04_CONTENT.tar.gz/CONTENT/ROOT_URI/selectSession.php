<?php 
$examType = $_GET['type'];
if ($examType == 'final') {
	$final = true;
}elseif ($examType == 'internal') {
	$internal = true;
}


 ?>

<?php if ($_SESSION['LoggedIn']): ?>




<div class="container">
 	<div class="col-sm-9 ml-auto mr-auto">
		<div class="tab-content" id="pills-tabContent">
			<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
	            <div class="col-sm-12  border border-primary shadow rounded pt-2">

	            	<?php if ($internal): ?>

					 <h2 style="text-align: center;">Please select the Session</h2>
					 <hr>
					 <div class="col-sm-6 ml-auto mr-auto">
					 	<form method="GET" action="internalExamQues" enctype="multipart/form-data">

						 <div class="form-group">
						  <label for="sel1">Select Session</label>

							<select name="session" class="form-control" value="Select Session"> 
								<?php

								$sql1 = "SELECT DISTINCT(SESSION) FROM FRP_TB_STUDENT_REGISTER";

								$result1 = mysqli_query($link,$sql1);
								while ($row = mysqli_fetch_array($result1)){
								echo "<option value='". $row['SESSION'] ."'>" .$row['SESSION'] ."</option>" ;
								}
								?> 
							 </select>
						   </div> 
						   <div class="form-group">
						   		<input type="submit" name="submit" value="Submit" class="btn btn-success btn-block">
						   </div>
					   </div>



					 <?php elseif ($final): ?>
					 	<h2 style="text-align: center;">Please select the Session</h2>
					 <hr>
					 <div class="col-sm-6 ml-auto mr-auto">
					 	<form method="GET" action="finalExamQues" enctype="multipart/form-data">

						 <div class="form-group">
						  <label for="sel1">Select Session</label>

							<select name="session" class="form-control" value="Select Session"> 
								<?php

								$sql1 = "SELECT DISTINCT(SESSION) FROM FRP_TB_STUDENT_REGISTER";

								$result1 = mysqli_query($link,$sql1);
								while ($row = mysqli_fetch_array($result1)){
								echo "<option value='". $row['SESSION'] ."'>" .$row['SESSION'] ."</option>" ;
								}
								?> 
							 </select>
						   </div> 
						   <div class="form-group">
						   		<input type="submit" name="submit" value="Submit" class="btn btn-success btn-block">
						   </div>
					   </div>




					 <?php endif; ?>

					 
					 
				</div>
			</div>
		</div>
	</div>
</div>

<?php else: ?>
	<h1>You are not authorized</h1>
    <h4>Please Log in <a href="/sign">here</a></h4>
<?php endif; ?>


