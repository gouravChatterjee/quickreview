<div class="jumbotron text-xs-center">
  <h1 class="display-3">Thank You!</h1>
  <p class="lead"><strong>You have successfully set the examination date. Wait for the admin confirmation.</strong></p>
  <hr>
  
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="home" role="button">Continue to homepage</a>
  </p>
</div>