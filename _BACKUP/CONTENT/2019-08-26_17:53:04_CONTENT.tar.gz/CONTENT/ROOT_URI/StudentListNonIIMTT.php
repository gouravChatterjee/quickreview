<script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
 </script>
<?php 
	$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);

	if(mysqli_connect_error()){
		die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
	}
	$franId = $_SESSION['franId'];

	$sql = "SELECT * FROM FRP_TB_NON_STUDENT_REGISTER  WHERE FRANCHISE_ID='$franId' ORDER BY FRP_NON_STUDENT_ID ASC";

	$result = mysqli_query($link,$sql);
	



 ?>





<div class="container">

	<div class="col-sm-12 ml-auto mr-auto">
		<div class="tab-content" id="pills-tabContent">
			<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
	            <div class="col-sm-12  border border-primary shadow rounded pt-2">
	            	<h1 style="text-align: center;">Students List(Non-IIMTT)</h1>
	            	<hr>
	            	<div class="table-responsive">
		            	<table class="table table-bordered table-hover" id="taa">
						  <thead class="thead-dark">
						    <tr>
						      <th scope="col">Id</th>
						      <th scope="col">Name</th>
						      <th scope="col">D.O.B</th>
						      <th scope="col">Phone</th>
						      <th scope="col">Email</th>
						      <th scope="col">Programs</th>
						      <th scope="col">Session</th>
						      <th scope="col">Enrollment Date</th>
						      <th scope="col">Action</th>
						      
						      
						    </tr>
						   </thead>
						    
						     	
						     
						      <tbody>
						      	<?php 
						      		if($result){
										if(mysqli_num_rows($result)>0){
											while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
												$nonId = $row['FRP_NON_STUDENT_ID'];
												$name = $row['STUDENT_NAME'];
												$dob = $row['DOB'];
												$phn = $row['PHONE_NO'];
												$email = $row['EMAIL'];
												$program = $row['PROGRAM'];
												$session = $row['SESSION'];
												$enrollDate = $row['DATE_OF_ENROLLMENT'];

												echo '<tr>
												      <td>'.$nonId.'</td>
												      
												      <td>'.$name.'</td>
												      <td>'.$dob.'</td>
												      <td>'.$phn.'</td>
												      <td>'.$email.'</td>
												      <td>'.$program.'</td>
												      <td>'.$session.'</td>
												      <td>'.$enrollDate.'</td>
												      <td><div class="dropdown">
													  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
													    
													  </button>
													  <div class="dropdown-menu">
													    <a class="dropdown-item" href="removeStudent?nonId='.$nonId.'">Delete</a>
													    <a class="dropdown-item" href="#">Update</a>
													    
													  </div>
													</div></td>
												      
								 
												  </tr>';




											}
										}else{
											$GLOBALS['alert_info'] .= DaddToBsAlert("Sorry! No record found!");
										}
								}

								if ($GLOBALS['alert_info']!="") {
									  echo $GLOBALS['alert_info'];
									}



						      	 ?>
						      </tbody>
						  </table>
	            </div>
	        </div>
	    </div>
	</div>
</div>
</div>
