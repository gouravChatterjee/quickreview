<script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
 </script>

<script type="text/javascript">
    function calculateMarks(internal,attandance,final,net) {
        var internalMarks = document.getElementById(internal).value;
        var attandanceMarks = document.getElementById(attandance).value;
        var finalMarks = document.getElementById(final).value;
        if (internalMarks>30) {
            alert("Internal Marks cannot be more than 30");
        }
        if (attandanceMarks>20) {
            alert("Attandance Marks cannot be more than 20");
        }
        if (finalMarks > 50) {
            alert("Final Marks cannot be more than 50");
        }
        // console.log(internalMarks);        
        // console.log(attandanceMarks);        
        // console.log(finalMarks);  
        var netMarks = parseInt(internalMarks)+parseInt(attandanceMarks)+parseInt(finalMarks);
        netMarks = netMarks/2;
        document.getElementById(net).value = netMarks;
        // console.log(netMarks);      


    }
</script>



<?php 
    $link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);
    if(mysqli_connect_error()){
        die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
    }
   $userId = $_SESSION['franId'];

   if (isset($_POST['submitBasic'])) {
       // $dm101 = $_POST['DM101net'];
       // echo $dm101;
    if (!empty($_POST['DM101net'])) {
        $dm101 = $_POST['DM101net'];
    }
    if (!empty($_POST['DM102net'])) {
        $dm1012 = $_POST['DM102net'];
    }
    if (!empty($_POST['DM103net'])) {
        $dm103 = $_POST['DM103net'];
    }
    if (!empty($_POST['DM101net'])) {
        $dm104 = $_POST['DM104net'];
    }
     $dm105 = $_POST['DM105net'];
     $dm106 = $_POST['DM106net'];
     $dm107 = $_POST['DM107net'];
     $dm108 = $_POST['DM108net'];

     $sql = "INSERT INTO  (`FRANCHISE_ID`, `STUDENT_NAME`, `DOB`, `PHONE_NO`, `EMAIL_ADDRESS`, `PROGRAM`, `SESSION`, `DATE_OF_ENROLLMENT`)VALUES('$franId', '$sName', '$dob', '$phn', '$email', '$program', '$session', '$dateEnroll')";


       
   }

  

 ?>

<?php if ($_SESSION['LoggedIn']): ?>


<div class="container">
 	<div class="col-sm-12 ml-auto mr-auto">
	<div class="tab-content" id="pills-tabContent">
		<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
            <div class="col-sm-12  border border-primary shadow rounded pt-2">
            	<h2 style="text-align: center;"><i class="fas fa-school"></i> Exam Marks System</h2>
            	<hr>
                <h4 style="text-align: center;"><i class="fas fa-book"></i> Theory Marks</h4>
                <hr>
                <?php if (isset($_GET)): ?>

                    <?php if (isset($_GET['studentSelection'])): ?>
                        <h4 style="text-align: center;">Please select the Student</h4>
                         
                         <div class="col-sm-6 ml-auto mr-auto">
                            <form method="GET" action="uploadAnswer" enctype="multipart/form-data">

                             <div class="form-group">
                              <!-- <label for="sel1">Select Session</label> -->

                                <select name="student" class="form-control" value="Select Student"> 
                                  <?php

                                    $sql1 = "SELECT * FROM FRP_TB_STUDENT_REGISTER WHERE FRANCHISE_ID = $userId";

                                    $result1 = mysqli_query($link, $sql1);
                                    while ($row = mysqli_fetch_array($result1)){
                                    echo "<option value='". $row['FRP_STUDENT_ID'] ."'>" .$row['FRP_STUDENT_ID']. " - ". $row['STUDENT_NAME'] ."</option>" ;
                                    }
                                    ?>        
                                </select>
                               </div> 
                               <div class="form-group">
                                    <input type="submit" name="submit" value="Submit" class="btn btn-success btn-block">
                               </div>
                           </div>

                    <?php else: ?>
                        <?php 
                            $student = $_GET['student'];
                            $sql = "SELECT * FROM FRP_TB_STUDENT_REGISTER WHERE FRP_STUDENT_ID = '$student'";
                            $result = mysqli_query($link,$sql);
                            if(mysqli_num_rows($result)>0){
                            $row = mysqli_fetch_array($result,MYSQLI_ASSOC);

                            $program = $row["PROGRAM"];
                            $program = explode (",", $program);
                            if (in_array('IIMTT Basic', $program) && in_array('IIMTT Advance', $program)){
                                $bothProgram = true;
                            }elseif (in_array('IIMTT Basic', $program)) {
                                $basic = true;
                            }else{
                                $advance = true;
                            }
                        }



                         ?>

                         
                         <h5><i class="fas fa-angle-double-right"></i>Montessori Diploma, Advanced Montessori Diploma</h5>
                            <hr>
                            <div class="table-responsive">
                                <form method="GET" id="iimttregform">
                                <table class="table table-bordered table-hover" id="taa">
                                  <thead class="thead-dark">
                                    <tr>
                                      <th scope="col">Subject</th>
                                      <th scope="col">Subject Code</th>
                                      <th scope="col">Internal Exam (30)</th>
                                      <th scope="col">Attandance (20)</th>
                                      <th scope="col">Final Exam (50)</th>
                                      <th scope="col">Net Marks (50)</th>
                                    </tr>
                                   </thead>
                                    
                                      <tbody>
                                        <tr>
                                            <td scope="col">Chapter 1</td>
                                            <td scope="col">DM101</td>
                                            <td><input class="form-control" type="number" id="DM101internal" name="DM101internal" placeholder="Enter the marks" required ></td>
                                            <td><input class="form-control" type="number" id="DM101attandance" name="DM101attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM101final" name="DM101final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DM101net" type="number" name="DM101net" placeholder="Net Marks" readonly required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DM101getmarks" onClick="calculateMarks('DM101internal','DM101attandance','DM101final','DM101net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                               
                                           
                                        </tr>
                                        <tr>
                                            <td scope="col">Chapter 2</td>
                                            <td scope="col">DM102</td>
                                             <td><input class="form-control" type="number" id="DM102internal" name="DM102internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM102attandance" name="DM102attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM102final" name="DM102final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DM102net" type="number" name="DM102net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DM102getmarks" onClick="calculateMarks('DM102internal','DM102attandance','DM102final','DM102net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                           
                                            
                                        </tr>
                                        <tr>
                                            <td scope="col">Chapter 3</td>
                                            <td scope="col">DM103</td>
                                             <td><input class="form-control" type="number" id="DM103internal" name="DM103internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM103attandance" name="DM103attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM103final" name="DM103final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DM103net" type="number" name="DM103net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DM103getmarks" onClick="calculateMarks('DM103internal','DM103attandance','DM103final','DM103net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                           
                                        </tr>
                                        <tr>
                                            <td scope="col">Chapter 4</td>
                                            <td scope="col">DM104</td>
                                             <td><input class="form-control" type="number" id="DM104internal" name="DM104internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM104attandance" name="DM104attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM104final" name="DM104final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DM104net" type="number" name="DM104net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DM104getmarks" onClick="calculateMarks('DM104internal','DM104attandance','DM104final','DM104net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                            
                                            
                                        </tr>
                                        <tr>
                                            <td scope="col">Chapter 5</td>
                                            <td scope="col">DM105</td>
                                             <td><input class="form-control" type="number" id="DM105internal" name="DM105internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM105attandance" name="DM105attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM105final" name="DM105final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DM105net" type="number" name="DM105net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DM105getmarks" onClick="calculateMarks('DM105internal','DM105attandance','DM105final','DM105net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                             
                                        </tr>
                                        <tr>
                                            <td scope="col">Chapter 6</td>
                                            <td scope="col">DM106</td>
                                             <td><input class="form-control" type="number" id="DM106internal" name="DM106internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM106attandance" name="DM106attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM106final" name="DM106final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DM106net" type="number" name="DM106net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DM106getmarks" onClick="calculateMarks('DM106internal','DM106attandance','DM106final','DM106net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                            
                                        </tr>
                                        <tr>
                                            <td scope="col">Chapter 7</td>
                                            <td scope="col">DM107</td>
                                             <td><input class="form-control" type="number" id="DM107internal" name="DM107internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM107attandance" name="DM107attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM107final" name="DM107final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DM107net" type="number" name="DM107net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DM107getmarks" onClick="calculateMarks('DM107internal','DM107attandance','DM107final','DM107net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                           
                                        </tr>
                                        <tr>
                                            <td scope="col">Chapter 8</td>
                                            <td scope="col">DM108</td>
                                             <td><input class="form-control" type="number" id="DM108internal" name="DM108internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM108attandance" name="DM108attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DM108final" name="DM108final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DM108net" type="number" name="DM108net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DM108getmarks" onClick="calculateMarks('DM108internal','DM108attandance','DM108final','DM108net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                            
                                        </tr>

                                      </tbody>
                                 
                                  </table>
                                  <button type="submit" class="btn btn-lg btn-success float-right" name="submitBasic">Submit</button>
                                   </form>
                              </div>
                              <hr>
                              <h5><i class="fas fa-angle-double-right"></i>Advanced Montessori Diploma</h5>
                            <hr>
                            <div class="table-responsive">
                                <form method="post" id="iimttregform">
                                <table class="table table-bordered table-hover" id="taa">
                                  <thead class="thead-dark">
                                    <tr>
                                      <th scope="col">Subject</th>
                                      <th scope="col">Subject Code</th>
                                      <th scope="col">Internal Exam (30)</th>
                                      <th scope="col">Attandance (20)</th>
                                      <th scope="col">Final Exam (50)</th>
                                      <th scope="col">Net Marks (50)</th>
                                    </tr>
                                   </thead>
                                    
                                      <tbody>
                                        <tr>
                                            <td scope="col">Chapter 9</td>
                                            <td scope="col">DA101</td>
                                             <td><input class="form-control" type="number" id="DA101internal" name="DA101internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA101attandance" name="DA101attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA101final" name="DA101final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DA101net" type="number" name="DA101net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DA101getmarks" onClick="calculateMarks('DA101internal','DA101attandance','DA101final','DA101net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                        </tr>
                                         <tr>
                                            <td scope="col">Chapter 10</td>
                                            <td scope="col">DA102</td>
                                             <td><input class="form-control" type="number" id="DA102internal" name="DA102internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA102attandance" name="DA102attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA102final" name="DA102final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DA102net" type="number" name="DA102net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DA102getmarks" onClick="calculateMarks('DA102internal','DA102attandance','DA102final','DA102net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                        </tr>
                                         <tr>
                                            <td scope="col">Chapter 11</td>
                                            <td scope="col">DA103</td>
                                            <td><input class="form-control" type="number" id="DA103internal" name="DA103internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA103attandance" name="DA103attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA103final" name="DA103final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DA103net" type="number" name="DA103net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DA103getmarks" onClick="calculateMarks('DA103internal','DA103attandance','DA103final','DA103net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                        </tr>
                                         <tr>
                                            <td scope="col">Chapter 12</td>
                                            <td scope="col">DA104</td>
                                            <td><input class="form-control" type="number" id="DA104internal" name="DA104internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA104attandance" name="DA104attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA104final" name="DA104final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DA104net" type="number" name="DA104net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DA104getmarks" onClick="calculateMarks('DA104internal','DA104attandance','DA104final','DA104net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                        </tr>
                                         <tr>
                                            <td scope="col">Chapter 13</td>
                                            <td scope="col">DA105</td>
                                            <td><input class="form-control" type="number" id="DA105internal" name="DA105internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA105attandance" name="DA105attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA105final" name="DA105final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DA105net" type="number" name="DA105net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DA105getmarks" onClick="calculateMarks('DA105internal','DA105attandance','DA105final','DA105net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td scope="col">Chapter 14</td>
                                            <td scope="col">DA106</td>
                                             <td><input class="form-control" type="number" id="DA106internal" name="DA106internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA106attandance" name="DA106attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA106final" name="DA106final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DA106net" type="number" name="DA106net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DA106getmarks" onClick="calculateMarks('DA106internal','DA106attandance','DA106final','DA106net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td scope="col">Chapter 15</td>
                                            <td scope="col">DA107</td>
                                             <td><input class="form-control" type="number" id="DA107internal" name="DA107internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA107attandance" name="DA107attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA107final" name="DA107final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DA107net" type="number" name="DA107net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DA107getmarks" onClick="calculateMarks('DA107internal','DA107attandance','DA107final','DA107net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td scope="col">Chapter 16</td>
                                            <td scope="col">DA108</td>
                                             <td><input class="form-control" type="number" id="DA108internal" name="DA108internal" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA108attandance" name="DA108attandance" placeholder="Enter the marks" required></td>
                                            <td><input class="form-control" type="number" id="DA108final" name="DA108final" placeholder="Enter the marks" required></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col"> <input class="form-control" id="DA108net" type="number" name="DA108net" placeholder="Net Marks" readonly value="" required></div>
                                                    <div class="col"><button type="button" class="btn btn-success" id="DA108getmarks" onClick="calculateMarks('DA108internal','DA108attandance','DA108final','DA108net');">Get Marks</button></div>
                                                </div>
                                            </td>
                                        </tr>
                                      </tbody>
                                  </table>
                                  <button type="submit" class="btn btn-lg btn-success float-right" name="submitAdvanced">Submit</button>
                              </form>
                              </div>
                              <br>


                    
                        

                    <?php endif ?>
                <?php endif?>



               



            </div>
        </div>
    </div>
	</div>
</div>








<?php else: ?>
	<h1>You are not authorized</h1>
	<h4>Please Log in <a href="/sign">here</a></h4>


<?php endif; ?>

