<!-- <div class="DCenterAll">
  <h3 class="text-center">System Admin</h3>
</div> -->
<div class="container">
  <script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
  </script>



  <?php
// phpinfo();

  if (isset($_GET)){
    if (isset($_GET['CreateBackup'])){
        if     ($_GET['CreateBackup']=='DB'){

          // var_dump($url);
        }
        elseif ($_GET['CreateBackup']=='CONFIG'){
          if (!file_exists('_BACKUP/CONFIG')) mkdir('_BACKUP/CONFIG', 0755, true); exec('tar zcf _BACKUP/CONFIG/$(date +%F_%T)_CONFIG.tar.gz CONFIG/*', $output, $return);
          if($return==0) echo "CONFIG backup success <br>"; else echo "CONFIG backup fail,check destination folder! <br>"; echo '<br> <button onclick="window.history.back();">Go Back</button>'; echo "<meta http-equiv='refresh' content='2;url=".$_SERVER['HTTP_REFERER']."'>";
        }
        elseif ($_GET['CreateBackup']=='CONTENT'){
          if (!file_exists('_BACKUP/CONTENT')) mkdir('_BACKUP/CONTENT', 0755, true); exec('tar zcf _BACKUP/CONTENT/$(date +%F_%T)_CONTENT.tar.gz CONTENT/*', $output, $return);
          if($return==0) echo "CONTENT backup success <br>"; else echo "CONTENT backup fail,check destination folder! <br>"; echo '<br> <button onclick="window.history.back();">Go Back</button>'; echo "<meta http-equiv='refresh' content='2;url=".$_SERVER['HTTP_REFERER']."'>";
        }
        elseif ($_GET['CreateBackup']=='DATA'){
          if (!file_exists('_BACKUP/DATA')) mkdir('_BACKUP/DATA', 0755, true); exec('tar zcf _BACKUP/DATA/$(date +%F_%T)_DATA.tar.gz CONTENT/DATA/*', $output, $return);
          if($return==0) echo "DATA backup success <br>"; else echo "DATA backup fail,check destination folder! <br>"; echo '<br> <button onclick="window.history.back();">Go Back</button>'; echo "<meta http-equiv='refresh' content='2;url=".$_SERVER['HTTP_REFERER']."'>";
        }
        elseif ($_GET['CreateBackup']=='UPLOADS'){
          if (!file_exists('_BACKUP/UPLOADS')) mkdir('_BACKUP/UPLOADS', 0755, true); exec('tar zcf _BACKUP/UPLOADS/$(date +%F_%T)_UPLOADS.tar.gz CONTENT/UPLOADS/*', $output, $return);
          if($return==0) echo "UPLOADS backup success <br>"; else echo "UPLOADS backup fail,check destination folder! <br>",$return; echo '<br> <button onclick="window.history.back();">Go Back</button>'; echo "<meta http-equiv='refresh' content='2;url=".$_SERVER['HTTP_REFERER']."'>";
        }
        elseif ($_GET['CreateBackup']=='USERS'){
          if (!file_exists('_BACKUP/USERS')) mkdir('_BACKUP/USERS', 0755, true); exec('tar zcf _BACKUP/USERS/$(date +%F_%T)_USERS.tar.gz CONTENT/USERS/*', $output, $return);
          if($return==0) echo "USERS backup success <br>"; else echo "USERS backup fail,check destination folder! <br>"; echo '<br> <button onclick="window.history.back();">Go Back</button>'; echo "<meta http-equiv='refresh' content='2;url=".$_SERVER['HTTP_REFERER']."'>";
        }
        else {
          // code...
        }

      }

  elseif (isset($_GET['futurePlanForExceptionHandling'])) {
    // code...
  }
  else{
    echo $lnk,'<h3> DB Backup List </h3>
    MYSQL_HOST: '.MYSQL_HOST.' &nbsp; MYSQL_USER: '.MYSQL_USER.'&nbsp; MYSQL_PASS: '.MYSQL_PASS.'
    <h5> MYSQL_DB1: '.MYSQL_DB_BEANSTALKFP.' <a href="?CreateBackup=DB&DB='.MYSQL_DB_BEANSTALKFP.'"> + </a></h5>
    ';
    $link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);
    $listdbtables = array_column(mysqli_fetch_all($link->query('SHOW TABLES')),0);
    foreach($listdbtables as $result) {
    echo $result, '<br>';
    }
    // echo $listdbtables;


      foreach (glob('_BACKUP/DB/*.*') as $filename) echo $filename;

    echo '<hr><br> <h3> CONFIG(folder) Backup List <a href="?CreateBackup=CONFIG"> + </a> </h3>';
      foreach (glob('_BACKUP/CONFIG/*.*') as $filename) echo '<br>',$filename;

    echo '<hr><br> <h3> CONTENT(folder) Backup List <a href="?CreateBackup=CONTENT"> + </a> </h3>';
      foreach (glob('_BACKUP/CONTENT/*.*') as $filename) echo '<br>',$filename;

    echo '<hr><br> <h3> DATA(folder) Backup List <a href="?CreateBackup=DATA"> + </a> </h3>';
      foreach (glob('_BACKUP/DATA/*.*') as $filename) echo '<br>',$filename;

    echo '<hr><br> <h3> UPLOADS(folder) Backup List <a href="?CreateBackup=UPLOADS"> + </a> </h3>';
      foreach (glob('_BACKUP/UPLOADS/*.*') as $filename) echo '<br>',$filename;

    echo '<hr><br> <h3> USERS(folder) Backup List <a href="?CreateBackup=USERS"> + </a> </h3>';
    foreach (glob('_BACKUP/USERS/*.*') as $filename) echo '<br>',$filename;

  }

}

?>
