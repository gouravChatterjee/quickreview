<?php 

$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);

if(mysqli_connect_error()){
	die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}

if (isset($_POST['submit'])){


	if(isset($_POST['sName']))
		$sName = $_POST['sName'];
	if(isset($_POST['dob']))
		$dob = $_POST['dob'];
	if(isset($_POST['fathername']))
		$fathername = $_POST['fathername'];
	if(isset($_POST['mothername']))
		$mothername = $_POST['mothername'];
	if(isset($_POST['phn']))
		$phn = $_POST['phn'];
	if(isset($_POST['email']))
		$email = $_POST['email'];
	if(isset($_POST['program']))
		$program = $_POST['program'];
	if(isset($_POST['dateEnroll']))
		$dateEnroll = $_POST['dateEnroll'];
	
	$program = implode("", $program);

	$franId = $_SESSION['franId'];
	$session = $_POST['session'];
	

	
	
	
	

	// $itemid = mysqli_real_escape_string($link,$itemid);
	// $itemdesc = mysqli_real_escape_string($link,$itemdesc);
	// $cost = mysqli_real_escape_string($link,$cost);

	
	$sql = "INSERT INTO FRP_TB_NON_STUDENT_REGISTER (`FRANCHISE_ID`, `STUDENT_NAME`, `DOB`, `FATHER_NAME`, `MOTHER_NAME`, `PHONE_NO`, `EMAIL`, `PROGRAM`, `SESSION`, `DATE_OF_ENROLLMENT`)VALUES('$franId','$sName', '$dob', '$fathername', '$mothername', '$phn', '$email', '$program', '$session', '$dateEnroll')";

	$result = mysqli_query($link, $sql);
	

  	if(!$result){
		echo '<div class="alert alert-danger">There was a database error </div>';
		echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
		
	}else{

		D_js_alert("Successfully Registered NON-IIMTT Student");
		// D_js_location_href("registerStudents");
		 echo "<script>
		 	window.location.href='registerStudents';
		 	</script>";

		
		// echo '<div class="alert alert-success">Successfully Registered the student</div>
		// 	<a  href="registerStudents" class="btn btn-primary DCenterAll">Register More NON-IIMTT Students</a>';
		
		

		
	}

}




 ?>












