<script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
  </script>


<?php 
$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);
	if(mysqli_connect_error()){
		die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
	}

	$email = $_SESSION['user'];
	
	$sql = "SELECT * FROM BS_USER WHERE USER_EMAIL = '$email'";

   	$result = mysqli_query($link,$sql);
   	if ($result) {
   		if(mysqli_num_rows($result)>0){
   			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
   			$json = $row['USER_JSOND'];
   			$arr = json_decode($json, true);
   			foreach($arr as $key=>$value){
   				// echo $key."\n";
   				foreach ($value as $ke => $val) {
   					if ($ke == "Programs") {
   						$programs = explode(',',$val);
   						if (in_array("IIMTT", $programs))
						  {
						    $iimtt = true;
						    
						  }

						  if (in_array("YLE", $programs) || in_array("MAXBRAIN", $programs) || in_array("WRITO", $programs) || in_array("3P", $programs))
						  {
						    $non_iimtt = true;
						  }

   					}

   				}
			    
			}
   		}

   		 
   		
   	}


// $_SESSION['FRANCHISE_ID']="44";
function createFile($value)
{
	
	$franId = $_SESSION['franId'];
	
	mkdir("CONTENT/UPLOADS/FRANCHISE/".$franId."/JoiningCheckList/".$value, 0755, true);
	$myfile = fopen("CONTENT/UPLOADS/FRANCHISE/".$franId."/JoiningCheckList/".$value."/Recieved.txt", "w") or die("Unable to open file!");
	$txt = "Recieved\n";
	fwrite($myfile, $txt);
	
	fclose($myfile);
}



function checkFile($value){
	$franId = $_SESSION['franId'];
	if(file_exists("CONTENT/UPLOADS/FRANCHISE/".$franId."/JoiningCheckList/".$value."/Recieved.txt"))
		return true;
}


if (isset($_POST['submit'])) {
	
	if (!empty($_POST['1'])) {
		createFile(1);
	}
	if (!empty($_POST['2'])) {
		createFile(2);
	}
	if (!empty($_POST['3'])) {
		createFile(3);
	}
	if (!empty($_POST['4'])) {
		createFile(4);
	}
	if (!empty($_POST['5'])) {
		createFile(5);
	}
	if (!empty($_POST['6'])) {
		createFile(6);
	}
	if (!empty($_POST['7'])) {
		createFile(7);
	}
	if (!empty($_POST['8'])) {
		createFile(8);
	}
	if (!empty($_POST['9'])) {
		createFile(9);
	}
	if (!empty($_POST['10'])) {
		createFile(10);
	}
	if (!empty($_POST['11'])) {
		createFile(11);
	}
	if (!empty($_POST['12'])) {
		createFile(12);
	}
	if (!empty($_POST['13'])) {
		createFile(13);
	}
	if (!empty($_POST['14'])) {
		createFile(14);
	}
	if (!empty($_POST['15'])) {
		createFile(15);
	}
	// if (!empty($_POST['8'])) {
	// 	createFile(8);
	// }

	

}

if(isset($_POST['submit2'])) {
	
     if (!empty($_POST['16'])) {
		createFile(16);
	}
	if (!empty($_POST['17'])) {
		createFile(17);
	}
	if (!empty($_POST['18'])) {
		createFile(18);
	}
	if (!empty($_POST['19'])) {
		createFile(19);
	}
	if (!empty($_POST['20'])) {
		createFile(20);
	}


 }




 ?>

<?php if ($_SESSION['LoggedIn']): ?>


<?php if ($iimtt && $non_iimtt): ?>


<div class="container">

<div class="col-sm-12 ml-auto mr-auto">
	<div class="tab-content" id="pills-tabContent">
		<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
            <div class="col-sm-12  border border-primary shadow rounded pt-2">
            	<h1 style="text-align: center;">Joining Check List</h1>
            	<hr>
            	<h3>Teacher Training</h3>
            	<hr>
            	 <form method="POST">
            	<div class="table-responsive">
            	<table class="table table-bordered table-hover" id="taa">
				  <thead class="thead-dark">
				    <tr>
				      <th scope="col">Item Id</th>
				      <th scope="col">Area</th>
				      <th scope="col">Description</th>
				      <th scope="col">Resource Person</th>
				      <th scope="col">Recieved</th>
				      
				      
				    </tr>
				     </thead>
				    
				     	
				     
				      <tbody>
				    <tr id="1">
				    	<td>1</td>
				    	<td>Marketing</td>
				    	<td>Agreement Signing</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(1)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="1"></td>';
				    		}
				    	?>
				    	
				    	
				    </tr>
				    <tr>
				    	<td>2</td>
				    	<td>Administrative</td>
				    	<td>Receipt of sample application form</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(2)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="2"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>3</td>
				    	<td>Marketing</td>
				    	<td>Receipt of sample Prospectus</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(3)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="3"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>4</td>
				    	<td>Academic</td>
				    	<td>Receipt of Program of work</td>
				    	<td>BD Manager</td>
						<?php 
				    		if(checkFile(4)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="4"></td>';
				    		}
				    	?>				    	
				    </tr>
				    <tr>
				    	<td>5</td>
				    	<td>Administrative</td>
				    	<td>Receipt of Authorized Study Center Certificate</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(5)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="5"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>6</td>
				    	<td>Marketing</td>
				    	<td>Receipt of Misc marketing collateral designs</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(6)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="6"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>7</td>
				    	<td>Marketing</td>
				    	<td>Receipt of Standee</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(7)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="7"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>8</td>
				    	<td>Marketing</td>
				    	<td>Receipt of Flex Banner</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(8)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="8"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>9</td>
				    	<td>Marketing</td>
				    	<td>Receipt of Leaflets</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(9)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="9"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>10</td>
				    	<td>Academic Training</td>
				    	<td>Sample Album Explainer</td>
				    	<td>Academic Mentor</td>
				    	<?php 
				    		if(checkFile(10)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="10"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>11</td>
				    	<td>Admin Training</td>
				    	<td>Process Guidlines</td>
				    	<td>Academic Mentor</td>
				    	<?php 
				    		if(checkFile(11)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="11"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>12</td>
				    	<td>Academic Training</td>
				    	<td>All class Video handover practical videos</td>
				    	<td>Academic Mentor</td>
				    	<?php 
				    		if(checkFile(12)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="12"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>13</td>
				    	<td>Administrative</td>
				    	<td>Receipt of Books, Subject to receipt of payment</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(13)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="13"></td>';
				    		}
				    	?>
				    	
				    	
				    </tr>
				     <tr>
				    	<td>14</td>
				    	<td>IT</td>
				    	<td>Access Rights to Franchise Portal</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(14)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="14"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>15</td>
				    	<td>Academic Training</td>
				    	<td>Methodology Training</td>
				    	<td>Academic Mentor</td>
				    	<?php 
				    		if(checkFile(15)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="15"></td>';
				    		}
				    	?>
				    	
				    </tr>
				 
			  	</tbody>
			  </table>
			
			<button type="submit" class="btn btn-success float-right" name="submit">Submit</button>
			</div>
			</form>
			

			<hr>
            	<h3>Beanstalk 3P / Writo / Maxbrain</h3>
            	<hr>
            	<form method="POST">
            		
            	
            	<div class="table-responsive">
            	<table class="table table-bordered table-hover">
				  <thead class="thead-dark">
				    <tr>
				      <th scope="col">Item Id</th>
				      <th scope="col">Area</th>
				      <th scope="col">Description</th>
				      <th scope="col">Resource Person</th>
				      <th scope="col">Recieved</th>
				      
				      
				    </tr>
				    
				</thead>
				<tbody>
					<tr>
				    	<td>16</td>
				    	<td>Marketing</td>
				    	<td>Agreement Signing</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(16)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="16"></td>';
				    		}
				    	?>
				    </tr>
				    <tr>
				    	<td>17</td>
				    	<td>Marketing</td>
				    	<td>Receipt of Misc marketing collateral designs</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(17)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="17"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>18</td>
				    	<td>Administrative</td>
				    	<td>Receipt of Books, Subject to receipt of payment</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(18)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="18"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>19</td>
				    	<td>IT</td>
				    	<td>Access Rights to Franchise Portal</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(19)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="19"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>20</td>
				    	<td>Academic Training</td>
				    	<td>Methodology Training</td>
				    	<td>Academic Mentor</td>
				    	<?php 
				    		if(checkFile(20)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="20"></td>';
				    		}
				    	?>
				    	
				    </tr>
					
				</tbody>
			</table>
		
		<button type="submit" class="btn btn-success float-right" name="submit2">Submit</button>
		<br><br>
		</div>

        	
        	</form>
    	</div>
	</div>
</div>
</div>
</div>

<br>

	<?php elseif ($iimtt): ?>
<div class="container">

<div class="col-sm-12 ml-auto mr-auto">
	<div class="tab-content" id="pills-tabContent">
		<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
            <div class="col-sm-12  border border-primary shadow rounded pt-2">
            	<h1 style="text-align: center;">Joining Check List</h1>
            	<hr>
            	<h3>Teacher Training</h3>
            	<hr>
            	 <form method="POST">
            	<div class="table-responsive">
            	<table class="table table-bordered table-hover" id="taa">
				  <thead class="thead-dark">
				    <tr>
				      <th scope="col">Item Id</th>
				      <th scope="col">Area</th>
				      <th scope="col">Description</th>
				      <th scope="col">Resource Person</th>
				      <th scope="col">Recieved</th>
				      
				      
				    </tr>
				     </thead>
				    
				     	
				     
				      <tbody>
				    <tr id="1">
				    	<td>1</td>
				    	<td>Marketing</td>
				    	<td>Agreement Signing</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(1)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="1"></td>';
				    		}
				    	?>
				    	
				    	
				    </tr>
				    <tr>
				    	<td>2</td>
				    	<td>Administrative</td>
				    	<td>Receipt of sample application form</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(2)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="2"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>3</td>
				    	<td>Marketing</td>
				    	<td>Receipt of sample Prospectus</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(3)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="3"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>4</td>
				    	<td>Academic</td>
				    	<td>Receipt of Program of work</td>
				    	<td>BD Manager</td>
						<?php 
				    		if(checkFile(4)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="4"></td>';
				    		}
				    	?>				    	
				    </tr>
				    <tr>
				    	<td>5</td>
				    	<td>Administrative</td>
				    	<td>Receipt of Authorized Study Center Certificate</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(5)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="5"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>6</td>
				    	<td>Marketing</td>
				    	<td>Receipt of Misc marketing collateral designs</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(6)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="6"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>7</td>
				    	<td>Marketing</td>
				    	<td>Receipt of Standee</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(7)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="7"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>8</td>
				    	<td>Marketing</td>
				    	<td>Receipt of Flex Banner</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(8)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="8"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>9</td>
				    	<td>Marketing</td>
				    	<td>Receipt of Leaflets</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(9)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="9"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>10</td>
				    	<td>Academic Training</td>
				    	<td>Sample Album Explainer</td>
				    	<td>Academic Mentor</td>
				    	<?php 
				    		if(checkFile(10)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="10"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>11</td>
				    	<td>Admin Training</td>
				    	<td>Process Guidlines</td>
				    	<td>Academic Mentor</td>
				    	<?php 
				    		if(checkFile(11)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="11"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>12</td>
				    	<td>Academic Training</td>
				    	<td>All class Video handover practical videos</td>
				    	<td>Academic Mentor</td>
				    	<?php 
				    		if(checkFile(12)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="12"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>13</td>
				    	<td>Administrative</td>
				    	<td>Receipt of Books, Subject to receipt of payment</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(13)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="13"></td>';
				    		}
				    	?>
				    	
				    	
				    </tr>
				     <tr>
				    	<td>14</td>
				    	<td>IT</td>
				    	<td>Access Rights to Franchise Portal</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(14)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="14"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>15</td>
				    	<td>Academic Training</td>
				    	<td>Methodology Training</td>
				    	<td>Academic Mentor</td>
				    	<?php 
				    		if(checkFile(15)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="15"></td>';
				    		}
				    	?>
				    	
				    </tr>
				 
			  	</tbody>
			  </table>
			</div>
			<button type="submit" class="btn btn-success float-right" name="submit">Submit</button>
			</form>
			<br>
			</div>
	</div>
</div>
</div>
</div>
<br>



	<?php else: ?>
<div class="container">
<div class="col-sm-12 ml-auto mr-auto">
	<div class="tab-content" id="pills-tabContent">
		<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
            <div class="col-sm-12  border border-primary shadow rounded pt-2">
            	<h1 style="text-align: center;">Joining Check List</h1>
            	<hr>
            	<h3>Beanstalk 3P / Writo / Maxbrain</h3>
            	<hr>
            	<form method="POST">
            		
            	
            	<div class="table-responsive">
            	<table class="table table-bordered table-hover">
				  <thead class="thead-dark">
				    <tr>
				      <th scope="col">Item Id</th>
				      <th scope="col">Area</th>
				      <th scope="col">Description</th>
				      <th scope="col">Resource Person</th>
				      <th scope="col">Recieved</th>
				      
				      
				    </tr>
				    
				</thead>
				<tbody>
					<tr>
				    	<td>1</td>
				    	<td>Marketing</td>
				    	<td>Agreement Signing</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(16)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="16"></td>';
				    		}
				    	?>
				    </tr>
				    <tr>
				    	<td>2</td>
				    	<td>Marketing</td>
				    	<td>Receipt of Misc marketing collateral designs</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(17)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="17"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>3</td>
				    	<td>Administrative</td>
				    	<td>Receipt of Books, Subject to receipt of payment</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(18)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="18"></td>';
				    		}
				    	?>
				    	
				    </tr>
				    <tr>
				    	<td>4</td>
				    	<td>IT</td>
				    	<td>Access Rights to Franchise Portal</td>
				    	<td>BD Manager</td>
				    	<?php 
				    		if(checkFile(19)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="19"></td>';
				    		}
				    	?>
				    	
				    </tr>
				     <tr>
				    	<td>5</td>
				    	<td>Academic Training</td>
				    	<td>Methodology Training</td>
				    	<td>Academic Mentor</td>
				    	<?php 
				    		if(checkFile(20)){
				    			echo '<td>&#9989</td>';
				    		} else{
				    			echo '<td><input type="checkbox" name="20"></td>';
				    		}
				    	?>
				    	
				    </tr>
					
				</tbody>
			</table>
		
		<button type="submit" class="btn btn-success float-right" name="submit2">Submit</button>
		<br><br>
		</div>

        	
        	</form>


        	</div>
        </div>
    </div>
    </div>
</div>




	<?php endif; ?>



 <?php else: ?>
          <h1>You are not authorized</h1>
          <h4>Please Log in <a href="/sign">here</a></h4>
          
  <?php endif; ?>