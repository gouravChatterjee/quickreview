<script>
      if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
      }
 </script>


<?php 

	$franId = $_SESSION['franId'];
	$studentId = $_GET['student'];

   function checkFile($value){
    $franId = $_SESSION['franId'];
    $studentId = $_GET['student'];
    


    $files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/".$value."/*");
    if (count($files) > 0)
        return true;
    // if(file_exists("CONTENT/UPLOADS/FRANCHISE/".$franId."/InternalQuestion/".$value."/Recieved.txt"))
    //  return true;
    } 
    function checkFinal(){
        $franId = $_SESSION['franId'];
    	$studentId = $_GET['student'];
        $files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Final/*");
        if (count($files) > 0)
            return true;
    }


    

    // -----------------------------UPLOAD ANSWER SHEETS----------------------------

    if (isset($_FILES['upCover'])) {
        $cover = $_FILES['upCover']['name'];
        // echo '<div class="alert alert-danger">'.$_POST['upCover'].' </div>';
        // echo '<div class="alert alert-danger">hellllllooo </div>';
        

        $subject = $_POST['subject'];

         mkdir("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/".$subject,  0755, true);
         $target = "CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/".$subject."/".basename($cover);
          if (move_uploaded_file($_FILES['upCover']['tmp_name'], $target)) {
                    $msg = "Image uploaded successfully";
                    // echo "uploaded";
                }else{
                    $msg = "Failed to upload image";
                    // echo "not uploaded";
                }

           echo "<meta http-equiv='refresh' content='0'>";

         
    }

     if (isset($_FILES['upCoverFinal'])) {
        $cover = $_FILES['upCoverFinal']['name'];
        // echo '<div class="alert alert-danger">'.$_POST['upCover'].' </div>';
        // echo '<div class="alert alert-danger">hellllllooo </div>';
        $userId = $_SESSION["userId"];
        $profile = $userId."Profile";


         mkdir("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Final",  0755, true);
         $target = "CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Final/".basename($cover);
          if (move_uploaded_file($_FILES['upCoverFinal']['tmp_name'], $target)) {
                    $msg = "Image uploaded successfully";
                    // echo "uploaded";
                }else{
                    $msg = "Failed to upload image";
                    // echo "not uploaded";
                }

           echo "<meta http-equiv='refresh' content='0'>";

         
    }

//--------------------------------------------------------------------------------


 ?>

 <?php if ($_SESSION['LoggedIn']): ?>


<div class="container">
 	<div class="col-sm-9 ml-auto mr-auto">
	<div class="tab-content" id="pills-tabContent">
		<div class="tab-pane fade show active" id="pills-iimtt" role="tabpanel" aria-labelledby="pills-iimtt-tab">
            <div class="col-sm-12  border border-primary shadow rounded pt-2">
            	<h2 style="text-align: center;"> <i class="fas fa-school"></i> Exam Marks System</h2>
            	<hr>
                <h4 style="text-align: center;"><i class="fas fa-book"></i> Upload Answer sheets</h4>
                <hr>
                 <h5><i class="fas fa-angle-double-right"></i>Montessori Diploma, Advanced Montessori Diploma</h5>
                 
                  <div class="table-responsive">
		                
		                <table class="table table-bordered table-hover" id="taa">
		                  <thead class="thead-dark">
		                    <tr>
		                      <th scope="col">Subject</th>
		                      <th scope="col">Subject Code</th>
		                      <th scope="col">Internal Exam (30)</th>
		                    </tr>
		                   </thead>
		                    
		                      <tbody>
		                      	<tr>
		                      		<td scope="col">Chapter 1</td>
                                     <td scope="col">DM101</td>
                                     <?php   if(!checkFile("DM101")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm1" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="upload1" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DM101">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover1" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DM101/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>

		                      	</tr>
		                      	<tr>
		                      		<td scope="col">Chapter 2</td>
                                     <td scope="col">DM102</td>
                                     <?php   if(!checkFile("DM102")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm2" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="upload2" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DM102">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover2" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DM102/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>
		                      	</tr>
		                      	<tr>
		                      		<td scope="col">Chapter 3</td>
                                    <td scope="col">DM103</td>
                                    <?php   if(!checkFile("DM103")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm3" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="upload3" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DM103">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover3" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DM103/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>
		                      	</tr>
		                      	<tr>
		                      		<td scope="col">Chapter 4</td>
                                	<td scope="col">DM104</td>
                                	<?php   if(!checkFile("DM104")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm4" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover4" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DM104">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover4" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DM104/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>	
		                      	</tr>
		                      	<tr>
		                      		<td scope="col">Chapter 5</td>
                                	<td scope="col">DM105</td>
                                	<?php   if(!checkFile("DM105")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm5" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover5" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DM105">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover5" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DM105/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>	
		                      	</tr>
		                      	<tr>
		                      		<td scope="col">Chapter 6</td>
                                	<td scope="col">DM106</td>
                                	<?php   if(!checkFile("DM106")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm6" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover6" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DM106">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover6" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DM106/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>	
		                      	</tr>
		                      	<tr>
		                      		<td scope="col">Chapter 7</td>
                                	<td scope="col">DM107</td>	
                                	<?php   if(!checkFile("DM107")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm7" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover7" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DM107">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover7" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DM107/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>
		                      	</tr>
		                      	<tr>
		                      		<td scope="col">Chapter 8</td>
                                	<td scope="col">DM108</td>	
                                	<?php   if(!checkFile("DM108")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm8" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover8" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DM108">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover8" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DM108/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>
		                      	</tr>
		                      </tbody>
		                      	
		                  </table>
                  </div>
                   <hr>
                  <h5><i class="fas fa-angle-double-right"></i>Advanced Montessori Diploma</h5>
                  <div class="table-responsive">
                    <table class="table table-bordered table-hover" id="taa">
                      <thead class="thead-dark">
                        <tr>
                          <th scope="col">Subject</th>
                          <th scope="col">Subject Code</th>
                          <th scope="col">Internal Exam (30)</th>
                        </tr>
                       </thead>
                        
                          <tbody>
                          	<tr>
                          		<td scope="col">Chapter 9</td>
                                <td scope="col">DA101</td>
                                <?php   if(!checkFile("DA101")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm9" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover9" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DA101">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover9" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DA101/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>

                          	</tr>
                          	<tr>
                          		<td scope="col">Chapter 10</td>
                                <td scope="col">DA102</td>	
                                <?php   if(!checkFile("DA102")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm10" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover10" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DA102">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover10" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DA102/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>
                          	</tr>
                          	<tr>
                          		<td scope="col">Chapter 11</td>
                                <td scope="col">DA103</td>	
                                <?php   if(!checkFile("DA103")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm11" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover11" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DA103">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover11" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DA103/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>
                          	</tr>
                          	<tr>
                          		<td scope="col">Chapter 12</td>
                                <td scope="col">DA104</td>
                                <?php   if(!checkFile("DA104")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm12" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover12" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DA104">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover12" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DA104/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>	
                          	</tr>
                          	<tr>
                          		<td scope="col">Chapter 13</td>
                                <td scope="col">DA105</td>
                                <?php   if(!checkFile("DA105")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm13" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover13" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DA105">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover13" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DA105/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>		
                          	</tr>
                          	<tr>
                          		<td scope="col">Chapter 14</td>
                                <td scope="col">DA106</td>	
                                <?php   if(!checkFile("DA106")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm14" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover14" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DA106">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover14" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DA106/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>	
                          	</tr>
                          	<tr>
                          		<td scope="col">Chapter 15</td>
                                <td scope="col">DA107</td>	
                                <?php   if(!checkFile("DA107")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm15" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover15" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DA107">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover15" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DA107/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>	
                          	</tr>
                          	<tr>
                          		<td scope="col">Chapter 16</td>
                                <td scope="col">DA108</td>	
                                <?php   if(!checkFile("DA108")){   ?>
                                     <td scope="col"><div>
                                            <form id="inputForm16" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover16" type="file" style="display: none; color: inherit;" name="upCover"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="DA108">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover16" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div></td>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Internal/DA108/*");
						      			
						    			echo '<td><a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a></td>';
						    		}?>	
                          	</tr>

                          </tbody>
                      </table>
              </div>
              <hr>
               <h5><i class="fas fa-angle-double-right"></i>Upload Final Exam Answer Sheet:-</h5>
                <?php   if(!checkFinal()){   ?>
                                   <div class="ml-auto mr-auto">
                                            <form id="inputForm17" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="size" value="1000000">
                                             <input id="uploadCover17" type="file" style="display: none; color: inherit;" name="upCoverFinal"
                                             onchange="form.submit()" />
                                             <input type="hidden" name="subject" value="Final">
                                         </form>
                                            <a href="#" class="btn btn-primary" id="upload_link_cover17" style="text-decoration:none;"><i class="fa fa-upload"></i> Upload Answer Sheet</a>
                                        </div>
                                    <?php }else{ 
                                    	
                                    	$franId = $_SESSION['franId'];
    									$studentId = $_GET['student'];
    


   										$files = glob("CONTENT/UPLOADS/FRANCHISE/".$franId."/AnswerSheet/".$studentId."/Final/*");
						      			
						    			echo '<a href="/'.$files[0].'" class="btn btn-success" name="1" download><i class="fa fa-download"></i> Download</a><br>';
						    		}?>
						    		<br>
						    		<?php 
						    		$student = $_GET['student'];
						    		echo '<a href="ExamMarks?student='.$student.'" class="btn btn-info btn-block">Done</a><br>';

						    		 ?>
						    		 <p class="text-muted" style="text-align: center;"><span style="color: red">*</span> Upload all the answer sheets and then click on Done</p>
	    	
            </div>
            <br>
        
        </div>

    </div>
</div>
</div>

 <?php endif ?>
 <script type="text/javascript">
     $(function(){
            $("#upload_link_cover1").on('click', function(e){
                e.preventDefault();
                $("#upload1:hidden").trigger('click');
            });
        });
     $(function(){
            $("#upload_link_cover2").on('click', function(e){
                e.preventDefault();
                $("#upload2:hidden").trigger('click');
            });
        });
     $(function(){
            $("#upload_link_cover3").on('click', function(e){
                e.preventDefault();
                $("#upload3:hidden").trigger('click');
            });
        });
     $(function(){
            $("#upload_link_cover4").on('click', function(e){
                e.preventDefault();
                $("#uploadCover4:hidden").trigger('click');
            });
        });
     $(function(){
            $("#upload_link_cover5").on('click', function(e){
                e.preventDefault();
                $("#uploadCover5:hidden").trigger('click');
            });
        });
     $(function(){
            $("#upload_link_cover6").on('click', function(e){
                e.preventDefault();
                $("#uploadCover6:hidden").trigger('click');
            });
        });
     $(function(){
            $("#upload_link_cover7").on('click', function(e){
                e.preventDefault();
                $("#uploadCover7:hidden").trigger('click');
            });
        });
      $(function(){
            $("#upload_link_cover8").on('click', function(e){
                e.preventDefault();
                $("#uploadCover8:hidden").trigger('click');
            });
        });

       $(function(){
            $("#upload_link_cover9").on('click', function(e){
                e.preventDefault();
                $("#uploadCover9:hidden").trigger('click');
            });
        });

        $(function(){
            $("#upload_link_cover10").on('click', function(e){
                e.preventDefault();
                $("#uploadCover10:hidden").trigger('click');
            });
        });
         $(function(){
            $("#upload_link_cover11").on('click', function(e){
                e.preventDefault();
                $("#uploadCover11:hidden").trigger('click');
            });
        });
          $(function(){
            $("#upload_link_cover12").on('click', function(e){
                e.preventDefault();
                $("#uploadCover12:hidden").trigger('click');
            });
        });
           $(function(){
            $("#upload_link_cover13").on('click', function(e){
                e.preventDefault();
                $("#uploadCover13:hidden").trigger('click');
            });
        });
            $(function(){
            $("#upload_link_cover14").on('click', function(e){
                e.preventDefault();
                $("#uploadCover14:hidden").trigger('click');
            });
        });
             $(function(){
            $("#upload_link_cover15").on('click', function(e){
                e.preventDefault();
                $("#uploadCover15:hidden").trigger('click');
            });
        });
              $(function(){
            $("#upload_link_cover16").on('click', function(e){
                e.preventDefault();
                $("#uploadCover16:hidden").trigger('click');
            });
        });
              $(function(){
            $("#upload_link_cover17").on('click', function(e){
                e.preventDefault();
                $("#uploadCover17:hidden").trigger('click');
            });
        });

</script>