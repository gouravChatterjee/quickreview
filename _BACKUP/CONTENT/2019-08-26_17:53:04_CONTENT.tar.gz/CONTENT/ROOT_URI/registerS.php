<?php 

$link = mysqli_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PASS,MYSQL_DB_BEANSTALKFP);

if(mysqli_connect_error()){
	die("ERROR: UNABLE TO CONNECT: ".mysqli_connect_error());
}

if (isset($_POST['submit'])){


	if(isset($_POST['sName']))
		$sName = $_POST['sName'];
	if(isset($_POST['dob']))
		$dob = $_POST['dob'];
	if(isset($_POST['phn']))
		$phn = $_POST['phn'];
	if(isset($_POST['email']))
		$email = $_POST['email'];
	if(isset($_POST['program']))
		$program = $_POST['program'];
	if(isset($_POST['dateEnroll']))
		$dateEnroll = $_POST['dateEnroll'];
	
	$program = implode("", $program);

	$enrollId = "";

	$franId = $_SESSION['franId'];
	$session = $_POST['session'];
	

	
	
	
	

	// $itemid = mysqli_real_escape_string($link,$itemid);
	// $itemdesc = mysqli_real_escape_string($link,$itemdesc);
	// $cost = mysqli_real_escape_string($link,$cost);

	
	$sql = "INSERT INTO FRP_TB_STUDENT_REGISTER (`FRANCHISE_ID`, `STUDENT_NAME`, `DOB`, `PHONE_NO`, `EMAIL_ADDRESS`, `PROGRAM`, `SESSION`, `DATE_OF_ENROLLMENT`)VALUES('$franId', '$sName', '$dob', '$phn', '$email', '$program', '$session', '$dateEnroll')";

	$result = mysqli_query($link, $sql);
	

  	if(!$result){
		echo '<div class="alert alert-danger">There was a database error </div>';
		echo '<div class="alert alert-danger">' . mysqli_error($link) . '</div>';
		
	}else{
		$userId = $_SESSION['franId'];
		$notifiacationType = 'New Student Registration';
		$linkToGo = 'franchiseeList';
		$sql = "INSERT INTO BS_NOTIFICATION (`USER_ID`, `STATUS`, `LINK`, `NOTIFICATION_DETAILS`)VALUES('$userId', 'PENDING', '$linkToGo', '$notificationType')";

		$result = mysqli_query($link, $sql);



		$GLOBALS['alert_info'] .= DaddToBsAlert("Successfully registered the student");
		// D_js_location_href("registerStudents");
		 echo "<script>
		 	window.location.href='registerStudents';
		 	</script>";

		
		
		
	}

}
if ($GLOBALS['alert_info']!="") {
  echo $GLOBALS['alert_info'];
}




 ?>












<!-- <div class="regst">
<div class="container">
	
		
		<h1>Student Registration Form(IIMTT)</h1>

		<form>
		  <div class="form-group">
		    <label for="name">Name of Candidate</label>
		    <input type="text" class="form-control" id="nameofchild"  placeholder="Enter the name of child" name="sName">
		   
		  </div>

		   <div class="form-group">
		    <label for="dateofbirth">Date of Birth</label>
		    <input type="date" class="form-control" id="dob" name="dob">
		   
		  </div>
		  

		  <div class="form-group">
		    <label for="number">Phone no.</label>
		    <input type="number" class="form-control" id="nameofchild"  placeholder="Enter the phn no." name="phn">
		   
		  </div>

		  <div class="form-group">
		    <label for="exampleInputEmail1">Email address</label>
		    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email">
		    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
		  </div>


		  <label for="program">Select your program</label>
		  <div class="form-check">
		  	
		  	
		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]">
		    <label class="form-check-label" for="exampleCheck1">IIMTT</label>

		  </div>
		   <div class="form-check">
		  	
		  	
		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]">
		    <label class="form-check-label" for="exampleCheck1">YLE</label>
		    
		  </div>
		   <div class="form-check">
		  	
		  	
		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]">
		    <label class="form-check-label" for="exampleCheck1">MAXBRAIN</label>
		    
		  </div>
		   <div class="form-check">
		  	
		  	
		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]">
		    <label class="form-check-label" for="exampleCheck1">WRITO</label>
		    
		  </div>
		   <div class="form-check">
		  	
		  	
		    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="program[]">
		    <label class="form-check-label" for="exampleCheck1">3P</label>
		    
		  </div>

		  <div class="form-group">
		    <label for="exampleInputEmail1">Date of Enrollment</label>
		    <input type="date" class="form-control" id="dateenroll"  name="dateEnroll">
		   
		  </div>



		  
		  
		  <button type="submit" class="btn btn-primary">Submit</button>
		</form>
		
	</div>
	</div>

 -->